#!/usr/bin/env python3
"""
Model Comprehensive Analysis
============================

This script provides an in-depth, model-specific analysis across four dimensions:
1. Sentiment category distributions
2. Toxicity proportions
3. Politeness scores and feature counts
4. Top politeness strategy usage patterns
"""

import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'shared'))

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
from collections import defaultdict
from data_loader import load_dataset
from plotting_utils import setup_plot_style, save_figure

warnings.filterwarnings('ignore')

def create_model_comprehensive_analysis(df, output_dir='.'):
    """Create comprehensive model-specific analysis with four sub-analyses"""

    df_filtered = df[df['PromptTone'].isin(['Polite', 'Threatening'])].copy()

    # Set theme for all plots
    setup_plot_style()
    sns.set_theme(style="whitegrid", context="talk")
    tone_palette = {'Polite': 'royalblue', 'Threatening': 'orangered'}

    # --- Analysis 1: Sentiment Score Distribution by Model ---
    print("\n--- Generating Plot 1: Sentiment Score Analysis ---")
    df_filtered['SentimentCategory'] = pd.cut(
        df_filtered['Response_SentimentScore'],
        bins=[-float('inf'), -0.05, 0.05, float('inf')],
        labels=['Negative', 'Neutral', 'Positive'],
        right=False
    )

    g1 = sns.catplot(
        data=df_filtered,
        x='SentimentCategory',
        hue='PromptTone',
        col='Model',
        kind='count',
        col_wrap=2,
        height=7,
        aspect=1.2,
        palette=tone_palette,
        order=['Negative', 'Neutral', 'Positive'],
        legend_out=False
    )
    g1.fig.suptitle('1) Distribution of Response Sentiment Categories by Model', y=1.03, fontsize=24)
    g1.set_axis_labels("Sentiment Category (VADER)", "Count of Responses")
    g1.set_titles("Model: {col_name}")
    g1.add_legend(title='Prompt Tone')
    plt.tight_layout(rect=[0, 0, 1, 0.96])

    output_path = os.path.join(output_dir, 'sentiment_categories_by_model.png')
    save_figure(g1.fig, output_path)
    plt.close(g1.fig)

    # --- Analysis 2: Toxicity Score Proportions by Model ---
    print("\n--- Generating Plot 2: Toxicity Score Analysis ---")
    toxicity_labels = ['Very Low', 'Low', 'Moderate', 'High', 'Very High']
    df_filtered['ToxicityCategory'] = pd.cut(
        df_filtered['RoBERTa_Response_ToxicityScore'],
        bins=[-float('inf'), 0.1, 0.3, 0.5, 0.7, float('inf')],
        labels=toxicity_labels,
        right=False
    )
    df_filtered['ToxicityCategory'] = pd.Categorical(df_filtered['ToxicityCategory'], categories=toxicity_labels, ordered=True)

    # Calculate proportions for the stacked bar chart
    toxicity_proportions = df_filtered.groupby(['Model', 'PromptTone'])['ToxicityCategory'].value_counts(normalize=True).mul(100).rename('Percentage').reset_index()

    g2 = sns.catplot(
        data=toxicity_proportions,
        x='PromptTone',
        y='Percentage',
        hue='ToxicityCategory',
        col='Model',
        kind='bar',
        col_wrap=2,
        height=7,
        aspect=1.2,
        palette='rocket_r',
        legend_out=False
    )
    g2.fig.suptitle('2) Proportional Distribution of Response Toxicity by Model', y=1.03, fontsize=24)
    g2.set_axis_labels("Prompt Tone", "Percentage of Responses (%)")
    g2.set_titles("Model: {col_name}")
    g2.add_legend(title='Toxicity Category')
    plt.tight_layout(rect=[0, 0, 1, 0.96])

    output_path = os.path.join(output_dir, 'toxicity_proportions_by_model.png')
    save_figure(g2.fig, output_path)
    plt.close(g2.fig)

    # --- Analysis 3: Politeness Score and Feature Count by Model ---
    print("\n--- Generating Plot 3: Politeness Score & Feature Count Analysis ---")
    politeness_melted = df_filtered.melt(
        id_vars=['Model', 'PromptTone'],
        value_vars=['Response_ValidatedPolitenessScore', 'Response_ValidatedFeatureCount'],
        var_name='MetricType',
        value_name='Value'
    )
    politeness_melted['MetricType'] = politeness_melted['MetricType'].replace({
        'Response_ValidatedPolitenessScore': 'Politeness Score (1-5)',
        'Response_ValidatedFeatureCount': 'Politeness Feature Count'
    })

    g3 = sns.catplot(
        data=politeness_melted,
        x='MetricType',
        y='Value',
        hue='PromptTone',
        col='Model',
        kind='point',
        col_wrap=2,
        height=7,
        aspect=1.2,
        palette=tone_palette,
        dodge=0.3,
        capsize=0.1,
        legend_out=False
    )
    g3.fig.suptitle('3) Average Politeness Score vs. Feature Count by Model', y=1.03, fontsize=24)
    g3.set_axis_labels("Metric", "Average Value")
    g3.set_titles("Model: {col_name}")
    g3.add_legend(title='Prompt Tone')
    plt.tight_layout(rect=[0, 0, 1, 0.96])

    output_path = os.path.join(output_dir, 'politeness_metrics_by_model.png')
    save_figure(g3.fig, output_path)
    plt.close(g3.fig)

    # --- Analysis 4: Politeness Strategy Breakdown by Model ---
    print("\n--- Generating Plot 4: Politeness Strategy Breakdown Analysis ---")
    strategy_data = []
    for index, row in df_filtered.iterrows():
        strategies_str = row['Response_ValidatedStrategies']
        if pd.notna(strategies_str):
            strategies = strategies_str.split('; ')
            for strategy in strategies:
                parts = strategy.split(':')
                if len(parts) == 2:
                    try:
                        strategy_data.append({
                            'Model': row['Model'],
                            'PromptTone': row['PromptTone'],
                            'Strategy': parts[0].strip(),
                            'Count': int(parts[1].strip())
                        })
                    except ValueError:
                        continue
    df_strategies = pd.DataFrame(strategy_data)

    # Find the top 5 most used strategies overall for a cleaner plot
    top_strategies = df_strategies.groupby('Strategy')['Count'].sum().nlargest(5).index.tolist()
    df_top_strategies = df_strategies[df_strategies['Strategy'].isin(top_strategies)]

    g4 = sns.catplot(
        data=df_top_strategies,
        x='Strategy',
        y='Count',
        hue='PromptTone',
        col='Model',
        kind='bar',
        col_wrap=2,
        height=7,
        aspect=1.2,
        palette=tone_palette,
        order=top_strategies,
        estimator=sum,
        ci=None,
        legend_out=False
    )
    g4.fig.suptitle('4) Usage of Top 5 Politeness Strategies by Model', y=1.03, fontsize=24)
    g4.set_axis_labels("Politeness Strategy", "Total Times Strategy Was Used")
    g4.set_titles("Model: {col_name}")
    g4.add_legend(title='Prompt Tone')
    plt.tight_layout(rect=[0, 0, 1, 0.96])

    output_path = os.path.join(output_dir, 'strategy_usage_by_model.png')
    save_figure(g4.fig, output_path)
    plt.close(g4.fig)

    return df_filtered, df_strategies

def print_comprehensive_model_statistics(df_filtered, df_strategies):
    """Print detailed model-specific statistics"""
    print("\n" + "="*60)
    print("MODEL COMPREHENSIVE ANALYSIS STATISTICS")
    print("="*60)

    # Sentiment analysis by model
    print("\nSentiment Categories by Model:")
    sentiment_crosstab = pd.crosstab([df_filtered['Model'], df_filtered['SentimentCategory']],
                                   df_filtered['PromptTone'], margins=True)
    print(sentiment_crosstab)

    # Toxicity analysis by model
    print("\nToxicity Categories by Model:")
    toxicity_crosstab = pd.crosstab([df_filtered['Model'], df_filtered['ToxicityCategory']],
                                  df_filtered['PromptTone'], margins=True)
    print(toxicity_crosstab)

    # Politeness metrics by model
    print("\nPoliteness Metrics by Model:")
    politeness_stats = df_filtered.groupby(['Model', 'PromptTone'])[
        ['Response_ValidatedPolitenessScore', 'Response_ValidatedFeatureCount']
    ].agg(['mean', 'std'])
    print(politeness_stats)

    # Strategy usage by model
    print("\nTop Strategy Usage by Model:")
    strategy_summary = df_strategies.groupby(['Model', 'PromptTone', 'Strategy'])['Count'].sum().reset_index()
    top_strategies_by_model = strategy_summary.groupby('Model').apply(
        lambda x: x.nlargest(3, 'Count')
    ).reset_index(drop=True)
    print(top_strategies_by_model)

def main():
    """Main execution function"""
    script_dir = os.path.dirname(__file__)
    dataset_path = os.path.join(script_dir, '..', '..', 'final_dataset.csv')

    df = load_dataset(dataset_path)
    if df is None:
        return

    print("Starting Model Comprehensive Analysis...")

    output_dir = os.path.dirname(__file__)

    # Generate comprehensive analysis
    df_filtered, df_strategies = create_model_comprehensive_analysis(df, output_dir)

    # Print statistics
    print_comprehensive_model_statistics(df_filtered, df_strategies)

    print("\nModel Comprehensive Analysis completed!")

if __name__ == "__main__":
    main()