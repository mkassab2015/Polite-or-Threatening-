# Model Comprehensive Analysis

## Overview
This analysis provides an in-depth, model-specific examination of AI behavior across four key dimensions, allowing for detailed comparison of how different models respond to prompt tone variations.

## What This Analysis Shows

### 1. Sentiment Category Distribution by Model
- **Purpose**: Compare sentiment response patterns across different AI models
- **Categories**: Negative (<-0.05), Neutral (-0.05 to 0.05), Positive (>0.05)
- **Visualization**: Count plots faceted by model showing sentiment distribution
- **Key Insight**: Identifies which models maintain positive sentiment regardless of prompt tone

### 2. Toxicity Proportions by Model
- **Purpose**: Analyze toxicity risk patterns for each AI model
- **Categories**: Very Low, Low, Moderate, High, Very High (based on RoBERTa thresholds)
- **Visualization**: Stacked bar charts showing toxicity category percentages
- **Key Insight**: Reveals which models are most robust against generating toxic content

### 3. Politeness Metrics by Model
- **Purpose**: Compare politeness scores and feature usage across models
- **Metrics**: Response_ValidatedPolitenessScore (1-5) and Response_ValidatedFeatureCount
- **Visualization**: Point plots with error bars showing mean values
- **Key Insight**: Shows which models consistently maintain politeness vs. those that vary with tone

### 4. Strategy Usage by Model
- **Purpose**: Examine specific politeness strategies employed by different models
- **Focus**: Top 5 most frequently used politeness strategies
- **Visualization**: Bar charts showing total strategy usage by model and prompt tone
- **Key Insight**: Identifies model-specific patterns in politeness implementation

## Methodology
- **Faceted Visualization**: Separate subplots for each AI model enable direct comparison
- **Categorical Analysis**: Transforms continuous metrics into interpretable categories
- **Proportional Analysis**: Uses percentages to account for different sample sizes
- **Strategy Parsing**: Extracts and quantifies specific linguistic politeness features

## Model Comparison Framework

### Expected Model Behaviors
- **Robust Models**: Consistent behavior across prompt tones
- **Reactive Models**: Large differences between polite and threatening responses
- **Safety-Focused Models**: Lower toxicity regardless of input tone
- **Socially-Aware Models**: High politeness strategy usage

### Evaluation Dimensions
1. **Sentiment Consistency**: Ability to maintain positive sentiment under adversarial prompts
2. **Toxicity Resistance**: Robustness against generating harmful content
3. **Politeness Maintenance**: Consistency in courteous response generation
4. **Strategy Diversity**: Range and sophistication of politeness mechanisms

## Files Generated
- `sentiment_categories_by_model.png`: Sentiment distribution comparison across models
- `toxicity_proportions_by_model.png`: Toxicity risk patterns by model
- `politeness_metrics_by_model.png`: Politeness scores and features by model
- `strategy_usage_by_model.png`: Top politeness strategies usage by model
- Console output with detailed cross-tabulations and statistical summaries

## Model-Specific Insights

### GPT-4o
- Expected: High consistency, sophisticated strategy usage
- Focus: Professional tone maintenance across conditions

### Claude Sonnet 4
- Expected: Strong safety focus, consistent politeness
- Focus: Balanced response generation with high courtesy

### Gemini 2.5 Pro
- Expected: Technical competence with social awareness
- Focus: Task completion while maintaining appropriate tone

### DeepSeek Chat
- Expected: Variable sensitivity to prompt tone
- Focus: Reactive behavior patterns to input conditions

## Research Applications

### Model Selection
1. **Safety-Critical Applications**: Choose models with lowest toxicity variance
2. **Customer Service**: Select models with highest politeness consistency
3. **Educational Tools**: Prefer models with positive sentiment maintenance
4. **Content Moderation**: Use models with robust safety behaviors

### Model Development
1. **Training Insights**: Identify successful politeness strategies for training data
2. **Safety Improvements**: Learn from models with strong toxicity resistance
3. **Consistency Enhancement**: Study models with stable cross-condition behavior
4. **Strategy Implementation**: Adopt effective politeness mechanisms from top performers

## Interpretation Guide
- **Count Plots**: Higher bars indicate more responses in that category
- **Percentage Bars**: Show proportional distribution, useful for comparing models with different response patterns
- **Point Plots**: Dots show means, error bars show 95% confidence intervals
- **Strategy Bars**: Taller bars indicate more frequent use of specific politeness mechanisms

This comprehensive analysis enables informed decisions about model deployment based on specific behavioral requirements and use case constraints.