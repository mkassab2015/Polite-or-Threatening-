# Basic Stripplot Analysis

## Overview
This analysis provides a foundational overview of how AI models respond differently to polite versus threatening prompts across four key metrics.

## What This Analysis Shows

### 1. Response Sentiment Score
- **Purpose**: Measures the emotional tone of AI responses
- **Expected Pattern**: Polite prompts may elicit more positive/neutral responses, while threatening prompts might produce more negative responses
- **Key Insight**: Shows whether prompt tone affects the emotional valence of AI responses

### 2. Response Toxicity Score (RoBERTa-based)
- **Purpose**: Detects harmful, toxic, or inappropriate content in AI responses
- **Expected Pattern**: Threatening prompts might trigger higher toxicity scores in responses
- **Key Insight**: Reveals if aggressive prompts lead to more harmful response content

### 3. Response Politeness Score
- **Purpose**: Measures how polite and courteous the AI responses are
- **Expected Pattern**: Polite prompts should generally receive more polite responses
- **Key Insight**: Tests whether AI models mirror the tone of the input prompts

### 4. Response Length
- **Purpose**: Compares the verbosity of responses to different prompt tones
- **Expected Pattern**: May show differences in response elaboration based on prompt tone
- **Key Insight**: Indicates whether prompt tone affects how much AI models choose to elaborate

## Methodology
- Uses stripplots to show individual data points and distributions
- Compares responses between "Polite" and "Threatening" prompt tones
- Applies jitter to prevent point overlap for better visualization
- Different color palettes for each metric to aid interpretation

## Files Generated
- `basic_stripplot_analysis.png`: Complete 2x2 grid visualization
- Console output with descriptive statistics for each metric

## Interpretation Guide
- **Stripplots** show both individual responses and overall patterns
- **Wider spreads** indicate more variability in responses
- **Clear separations** between prompt tones suggest strong effects
- **Reference lines** (e.g., y=0 for sentiment) help interpret scores

This analysis serves as the foundation for understanding the basic relationships before diving into more complex, model-specific, and task-specific analyses.