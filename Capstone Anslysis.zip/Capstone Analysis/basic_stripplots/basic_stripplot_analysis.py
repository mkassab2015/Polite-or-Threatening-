#!/usr/bin/env python3
"""
Basic Stripplot Analysis
========================

This script creates a 2x2 grid of stripplots analyzing model responses
to polite vs. threatening prompts across four key metrics:
- Sentiment Score
- Toxicity Score
- Politeness Score
- Response Length
"""

import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'shared'))

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from data_loader import load_dataset
from plotting_utils import setup_plot_style, save_figure

def create_basic_stripplots(df, output_dir='.'):
    """Create 2x2 stripplot analysis"""
    # Filter the DataFrame to only include 'Polite' and 'Threatening' prompt tones
    df_filtered = df[df['PromptTone'].isin(['Polite', 'Threatening'])]

    # Set professional plot style
    setup_plot_style()
    sns.set_style("whitegrid")
    sns.set_context("talk")

    # Create a 2x2 subplot figure
    fig, axes = plt.subplots(2, 2, figsize=(18, 14))
    fig.suptitle('Analysis of Model Responses to Polite vs. Threatening Prompts', fontsize=24, y=1.02)

    # Plot 1: Sentiment Score of Response
    sns.stripplot(ax=axes[0, 0], x='PromptTone', y='Response_SentimentScore',
                  data=df_filtered, jitter=True, size=10, palette='viridis', alpha=0.7)
    axes[0, 0].set_title('1) Response Sentiment Score')
    axes[0, 0].set_xlabel('Prompt Tone')
    axes[0, 0].set_ylabel('Sentiment Score')
    axes[0, 0].axhline(0, color='grey', linestyle='--', linewidth=1.5)

    # Plot 2: Toxicity Score of Response
    sns.stripplot(ax=axes[0, 1], x='PromptTone', y='RoBERTa_Response_ToxicityScore',
                  data=df_filtered, jitter=True, size=10, palette='rocket', alpha=0.7)
    axes[0, 1].set_title('2) Response Toxicity Score')
    axes[0, 1].set_xlabel('Prompt Tone')
    axes[0, 1].set_ylabel('Toxicity Score')
    axes[0, 1].set_ylim(bottom=0)

    # Plot 3: Politeness Score of Response
    sns.stripplot(ax=axes[1, 0], x='PromptTone', y='Response_ValidatedPolitenessScore',
                  data=df_filtered, jitter=True, size=10, palette='mako', alpha=0.7)
    axes[1, 0].set_title('3) Response Politeness Score')
    axes[1, 0].set_xlabel('Prompt Tone')
    axes[1, 0].set_ylabel('Politeness Score')

    # Plot 4: Response Length
    sns.stripplot(ax=axes[1, 1], x='PromptTone', y='ResponseLength',
                  data=df_filtered, jitter=True, size=10, palette='flare', alpha=0.7)
    axes[1, 1].set_title('4) Response Length')
    axes[1, 1].set_xlabel('Prompt Tone')
    axes[1, 1].set_ylabel('Length (Number of Characters)')

    # Adjust layout
    plt.tight_layout(rect=[0, 0.03, 1, 0.95])

    # Save the figure
    output_path = os.path.join(output_dir, 'basic_stripplot_analysis.png')
    save_figure(fig, output_path)

    plt.show()
    return fig

def print_basic_statistics(df):
    """Print basic statistics for each metric"""
    df_filtered = df[df['PromptTone'].isin(['Polite', 'Threatening'])]

    print("\n" + "="*50)
    print("BASIC STATISTICS")
    print("="*50)

    print(f"\nSentiment Score by Prompt Tone:")
    print(df_filtered.groupby('PromptTone')['Response_SentimentScore'].describe())

    print(f"\nToxicity Score by Prompt Tone:")
    print(df_filtered.groupby('PromptTone')['RoBERTa_Response_ToxicityScore'].describe())

    print(f"\nPoliteness Score by Prompt Tone:")
    print(df_filtered.groupby('PromptTone')['Response_ValidatedPolitenessScore'].describe())

    print(f"\nResponse Length by Prompt Tone:")
    print(df_filtered.groupby('PromptTone')['ResponseLength'].describe())

def main():
    """Main execution function"""
    # Load dataset
    script_dir = os.path.dirname(__file__)
    dataset_path = os.path.join(script_dir, '..', '..', 'final_dataset.csv')

    df = load_dataset(dataset_path)
    if df is None:
        return

    print("Starting Basic Stripplot Analysis...")

    # Create output directory
    output_dir = os.path.dirname(__file__)

    # Generate plots
    create_basic_stripplots(df, output_dir)

    # Print statistics
    print_basic_statistics(df)

    print("\nBasic Stripplot Analysis completed!")

if __name__ == "__main__":
    main()