#!/usr/bin/env python3
"""
Response Length Analysis
========================

This script analyzes response length patterns across different models,
task categories, and prompt tones to understand verbosity differences.
"""

import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'shared'))

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from data_loader import load_dataset
from plotting_utils import setup_plot_style, save_figure

def create_response_length_analysis(df, output_dir='.'):
    """Create response length analysis"""

    # Filter for relevant data
    df_filtered = df[df['PromptTone'].isin(['Polite', 'Threatening'])].copy()

    # Set up plotting
    setup_plot_style()
    sns.set_style("whitegrid")

    # Create figure with 2x2 subplots
    fig, axes = plt.subplots(2, 2, figsize=(16, 12))
    fig.suptitle('Response Length Analysis', fontsize=18, y=0.98)

    # Plot 1: Response length distribution by prompt tone
    sns.boxplot(ax=axes[0,0], x='PromptTone', y='ResponseLength',
                data=df_filtered, palette='viridis')
    axes[0,0].set_title('Response Length by Prompt Tone')
    axes[0,0].set_ylabel('Response Length (characters)')

    # Plot 2: Response length by model
    sns.boxplot(ax=axes[0,1], x='Model', y='ResponseLength', hue='PromptTone',
                data=df_filtered, palette='husl')
    axes[0,1].set_title('Response Length by Model and Prompt Tone')
    axes[0,1].set_ylabel('Response Length (characters)')
    axes[0,1].tick_params(axis='x', rotation=45)

    # Plot 3: Average response length by model
    model_length_means = df_filtered.groupby(['Model', 'PromptTone'])['ResponseLength'].mean().unstack()
    model_length_means.plot(kind='bar', ax=axes[1,0], width=0.8)
    axes[1,0].set_title('Mean Response Length by Model')
    axes[1,0].set_ylabel('Mean Response Length (characters)')
    axes[1,0].tick_params(axis='x', rotation=45)
    axes[1,0].legend(title='Prompt Tone')

    # Plot 4: Response length distribution (histogram)
    for i, tone in enumerate(['Polite', 'Threatening']):
        tone_data = df_filtered[df_filtered['PromptTone'] == tone]['ResponseLength']
        axes[1,1].hist(tone_data, alpha=0.6, label=tone, bins=30, density=True)

    axes[1,1].set_title('Response Length Distribution')
    axes[1,1].set_xlabel('Response Length (characters)')
    axes[1,1].set_ylabel('Density')
    axes[1,1].legend()

    plt.tight_layout(rect=[0, 0.03, 1, 0.95])

    # Save the figure
    output_path = os.path.join(output_dir, 'response_length_analysis.png')
    save_figure(fig, output_path)
    plt.close(fig)

    return df_filtered

def print_length_statistics(df_filtered):
    """Print detailed response length statistics"""
    print("\n" + "="*60)
    print("RESPONSE LENGTH ANALYSIS")
    print("="*60)

    # Overall statistics
    print("\nOverall Response Length Statistics:")
    print(df_filtered.groupby('PromptTone')['ResponseLength'].describe())

    # Model-specific statistics
    print("\nResponse Length by Model:")
    model_stats = df_filtered.groupby(['Model', 'PromptTone'])['ResponseLength'].agg(['mean', 'std', 'median'])
    print(model_stats)

    # Length categories analysis
    df_filtered['LengthCategory'] = pd.cut(df_filtered['ResponseLength'],
                                          bins=[0, 500, 1000, 2000, float('inf')],
                                          labels=['Short (<500)', 'Medium (500-1000)',
                                                 'Long (1000-2000)', 'Very Long (>2000)'])

    print("\nResponse Length Categories:")
    category_counts = df_filtered.groupby(['PromptTone', 'LengthCategory']).size().unstack(fill_value=0)
    category_percentages = category_counts.div(category_counts.sum(axis=1), axis=0) * 100
    print(category_percentages.round(1))

    # Statistical significance testing
    from scipy import stats
    polite_lengths = df_filtered[df_filtered['PromptTone'] == 'Polite']['ResponseLength']
    threatening_lengths = df_filtered[df_filtered['PromptTone'] == 'Threatening']['ResponseLength']

    # Perform t-test
    t_stat, p_value = stats.ttest_ind(polite_lengths, threatening_lengths)
    print(f"\nStatistical Test (t-test):")
    print(f"T-statistic: {t_stat:.4f}")
    print(f"P-value: {p_value:.4f}")
    print(f"Significant difference: {'Yes' if p_value < 0.05 else 'No'}")

    # Effect size (Cohen's d)
    pooled_std = ((len(polite_lengths)-1)*polite_lengths.std()**2 +
                  (len(threatening_lengths)-1)*threatening_lengths.std()**2) / \
                 (len(polite_lengths) + len(threatening_lengths) - 2)
    cohens_d = (polite_lengths.mean() - threatening_lengths.mean()) / (pooled_std**0.5)
    print(f"Effect size (Cohen's d): {cohens_d:.4f}")

def main():
    """Main execution function"""
    script_dir = os.path.dirname(__file__)
    dataset_path = os.path.join(script_dir, '..', '..', 'final_dataset.csv')

    df = load_dataset(dataset_path)
    if df is None:
        return

    print("Starting Response Length Analysis...")

    output_dir = os.path.dirname(__file__)

    # Generate analysis
    df_filtered = create_response_length_analysis(df, output_dir)

    # Print statistics
    print_length_statistics(df_filtered)

    print("\nResponse Length Analysis completed!")

if __name__ == "__main__":
    main()