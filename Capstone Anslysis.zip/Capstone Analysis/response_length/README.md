# Response Length Analysis

## Overview
This analysis focuses specifically on how AI models adjust their verbosity and response length based on prompt tone, providing insights into whether threatening prompts lead to shorter, more defensive responses or longer, more explanatory ones.

## What This Analysis Shows

### 1. Response Length by Prompt Tone
- **Purpose**: Direct comparison of response lengths between polite and threatening prompts
- **Visualization**: Box plots showing length distributions
- **Key Insight**: Reveals whether prompt tone systematically affects response verbosity

### 2. Response Length by Model and Prompt Tone
- **Purpose**: Compare how different AI models adjust response length
- **Visualization**: Grouped box plots with model and prompt tone
- **Key Insight**: Identifies which models are most sensitive to prompt tone in their verbosity

### 3. Mean Response Length by Model
- **Purpose**: Show average response lengths across models and prompt tones
- **Visualization**: Bar chart with grouped bars for each model
- **Key Insight**: Quantifies the magnitude of length differences between conditions

### 4. Response Length Distribution
- **Purpose**: Show the overall distribution shape of response lengths
- **Visualization**: Overlapping histograms for polite vs. threatening responses
- **Key Insight**: Reveals whether distributions are similar or have different shapes

## Methodology
- **Statistical Testing**: Performs t-tests to determine statistical significance
- **Effect Size Calculation**: Computes Cohen's d to measure practical significance
- **Categorical Analysis**: Groups responses into length categories (Short, Medium, Long, Very Long)
- **Model Comparison**: Analyzes length patterns across different AI models

## Key Metrics
- **Mean Response Length**: Average character count per response type
- **Length Categories**:
  - Short: <500 characters
  - Medium: 500-1000 characters
  - Long: 1000-2000 characters
  - Very Long: >2000 characters
- **Statistical Significance**: P-value from independent t-test
- **Effect Size**: Cohen's d for practical significance

## Files Generated
- `response_length_analysis.png`: Complete 2x2 response length visualization
- Console output with detailed statistical analysis

## Interpretation Guide
- **Box Plot Elements**:
  - Center line: Median response length
  - Box: Interquartile range (25th-75th percentile)
  - Whiskers: Data range excluding outliers
  - Points: Outlier responses
- **Statistical Significance**:
  - P-value < 0.05: Statistically significant difference
  - Cohen's d interpretation: 0.2 (small), 0.5 (medium), 0.8 (large) effect
- **Length Categories**: Percentage breakdown helps understand response patterns

## Research Questions Addressed
1. Do AI models provide shorter responses to threatening prompts (defensive behavior)?
2. Are there consistent patterns in response length across different models?
3. What is the magnitude and practical significance of length differences?
4. Do certain models show more pronounced length adjustments than others?

## Expected Patterns
- **Defensive Response**: Shorter responses to threatening prompts
- **Explanatory Response**: Longer responses to clarify or de-escalate
- **Model Consistency**: Some models may show consistent patterns regardless of tone
- **Task Dependency**: Response length may depend on the specific task requirements

This analysis helps understand whether AI models use response length as a strategy for managing different prompt tones and whether this represents a form of adaptive communication or defensive behavior.