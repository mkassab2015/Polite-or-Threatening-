"""
Data loading utilities for capstone analysis
"""
import pandas as pd
import numpy as np

def load_dataset(filepath='final_dataset.csv'):
    """Load and return the dataset with basic preprocessing"""
    try:
        df = pd.read_csv(filepath)
        print(f"Dataset loaded successfully. Shape: {df.shape}")
        return df
    except FileNotFoundError:
        print(f"Error: {filepath} not found. Please ensure the file exists.")
        return None
    except Exception as e:
        print(f"Error loading dataset: {e}")
        return None

def get_dataset_info(df):
    """Print basic information about the dataset"""
    if df is not None:
        print("\nDataset Info:")
        print(f"Shape: {df.shape}")
        print(f"\nColumns: {list(df.columns)}")
        print(f"\nUnique Prompt Tones: {df['PromptTone'].unique()}")
        if 'Model' in df.columns:
            print(f"Unique Models: {df['Model'].unique()}")
        print(f"\nFirst few rows:")
        print(df.head())