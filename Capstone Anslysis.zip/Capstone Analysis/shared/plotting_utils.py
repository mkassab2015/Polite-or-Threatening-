"""
Common plotting utilities and styling for capstone analysis
"""
import matplotlib
matplotlib.use('Agg')  # Use non-interactive backend
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np

# Set global style
plt.style.use('default')
sns.set_palette("husl")

def setup_plot_style():
    """Setup consistent plot styling"""
    plt.rcParams['figure.figsize'] = (12, 8)
    plt.rcParams['font.size'] = 10
    plt.rcParams['axes.titlesize'] = 12
    plt.rcParams['axes.labelsize'] = 11
    plt.rcParams['xtick.labelsize'] = 9
    plt.rcParams['ytick.labelsize'] = 9
    plt.rcParams['legend.fontsize'] = 10

def get_color_palette(style='default'):
    """Get consistent color palettes"""
    palettes = {
        'default': ['#FF6B6B', '#4ECDC4'],
        'professional': ['#2E86AB', '#A23B72'],
        'contrast': ['#F18F01', '#C73E1D'],
        'muted': ['#7209B7', '#560BAD']
    }
    return palettes.get(style, palettes['default'])

def save_figure(fig, filename, dpi=300, bbox_inches='tight'):
    """Save figure with consistent settings"""
    fig.savefig(filename, dpi=dpi, bbox_inches=bbox_inches,
                facecolor='white', edgecolor='none')
    print(f"Figure saved: {filename}")

def create_2x2_subplots(figsize=(15, 12)):
    """Create standardized 2x2 subplot layout"""
    fig, axes = plt.subplots(2, 2, figsize=figsize)
    fig.suptitle('Analysis Results', fontsize=16, y=0.98)
    plt.tight_layout()
    return fig, axes