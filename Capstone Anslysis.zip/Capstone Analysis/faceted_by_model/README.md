# Faceted Model Analysis

## Overview
This analysis provides model-specific insights by creating separate visualizations for each AI model, allowing direct comparison of how different models respond to prompt tone variations.

## What This Analysis Shows

### 1. Sentiment Score by Model
- **Purpose**: Compare how different AI models' emotional responses vary with prompt tone
- **Visualization**: Line plots across task numbers, faceted by model
- **Key Insight**: Identifies which models are more sensitive to prompt tone in their emotional responses

### 2. Toxicity Score by Model
- **Purpose**: Analyze model-specific patterns in generating toxic or harmful content
- **Visualization**: Line plots showing toxicity trends across tasks
- **Key Insight**: Reveals which models are more prone to generating toxic responses under threatening prompts

### 3. Politeness Score by Model
- **Purpose**: Examine how different models maintain politeness under various prompt tones
- **Visualization**: Model-specific politeness trends across tasks
- **Key Insight**: Shows which models best maintain courtesy regardless of input tone

### 4. Response Length by Model
- **Purpose**: Compare verbosity patterns across different AI models
- **Visualization**: Response length trends by model and prompt tone
- **Key Insight**: Identifies models that significantly alter response length based on prompt tone

## Methodology
- **Faceted Visualization**: Uses `sns.relplot()` with `col='Model'` for model-specific subplots
- **Time Series Approach**: X-axis shows task numbers to reveal trends over the experiment
- **Line Plots with Markers**: Shows both individual data points and connecting trends
- **Color Coding**: Different hues for polite vs. threatening prompts

## Key Features
- **Model Comparison**: Direct visual comparison between AI models
- **Trend Analysis**: Line plots reveal patterns across different tasks
- **Reference Lines**: Neutral reference lines (e.g., y=0 for sentiment) aid interpretation
- **Professional Layout**: 2x2 grid arrangement with proper spacing and titles

## Files Generated
- `sentiment_by_model.png`: Sentiment analysis faceted by model
- `toxicity_by_model.png`: Toxicity analysis faceted by model
- `politeness_by_model.png`: Politeness analysis faceted by model
- `response_length_by_model.png`: Response length analysis faceted by model
- Console output with model-specific statistics

## Interpretation Guide
- **Parallel Lines**: Suggest consistent behavior regardless of prompt tone
- **Diverging Lines**: Indicate strong sensitivity to prompt tone
- **Model Differences**: Compare subplot patterns to identify model-specific behaviors
- **Trend Consistency**: Consistent trends across tasks suggest reliable model behavior

This analysis helps identify which AI models are most robust to prompt tone variations and which may be more susceptible to generating different response qualities based on input tone.