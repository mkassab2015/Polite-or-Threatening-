#!/usr/bin/env python3
"""
Faceted Model Analysis
======================

This script creates faceted visualizations showing how different AI models
respond to polite vs. threatening prompts across four key metrics.
Each metric is displayed in a separate figure with subplots for each model.
"""

import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'shared'))

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
from data_loader import load_dataset
from plotting_utils import setup_plot_style, save_figure

warnings.filterwarnings('ignore')

def create_faceted_analysis(df, output_dir='.'):
    """Create faceted plots showing analysis by AI model"""

    # Filter for only 'Polite' and 'Threatening' tones
    df_filtered = df[df['PromptTone'].isin(['Polite', 'Threatening'])].copy()

    # Extract the task number to create a clean, numerical x-axis
    df_filtered['TaskNumber'] = df_filtered['TaskID'].str.extract(r'(\d+)$').astype(int)

    # Sort the data to ensure lines connect points in the correct order
    df_filtered.sort_values(by=['Model', 'TaskNumber'], inplace=True)

    # Set professional plot style
    setup_plot_style()
    sns.set_theme(style="whitegrid", context="talk")

    print("\n--- Generating Plot 1: Response Sentiment Score ---")
    # Plot 1: Sentiment Score of Response
    g1 = sns.relplot(
        data=df_filtered,
        x='TaskNumber',
        y='Response_SentimentScore',
        hue='PromptTone',
        col='Model',
        kind='line',
        marker='o',
        height=6,
        aspect=1.2,
        col_wrap=2
    )
    g1.fig.suptitle('1) Response Sentiment Score by Model and Prompt Tone', y=1.03, fontsize=22)
    g1.set_axis_labels("Task Number", "Sentiment Score")
    g1.map(plt.axhline, y=0, color='grey', linestyle='--', linewidth=1.5)
    g1.set_titles("Model: {col_name}")
    g1.tight_layout(rect=[0, 0, 1, 0.96])

    output_path = os.path.join(output_dir, 'sentiment_by_model.png')
    save_figure(g1.fig, output_path)
    plt.close(g1.fig)

    print("\n--- Generating Plot 2: Response Toxicity Score ---")
    # Plot 2: Toxicity Score of Response
    g2 = sns.relplot(
        data=df_filtered,
        x='TaskNumber',
        y='RoBERTa_Response_ToxicityScore',
        hue='PromptTone',
        col='Model',
        kind='line',
        marker='o',
        height=6,
        aspect=1.2,
        col_wrap=2,
        palette='rocket'
    )
    g2.fig.suptitle('2) Response Toxicity Score by Model and Prompt Tone', y=1.03, fontsize=22)
    g2.set_axis_labels("Task Number", "Toxicity Score")
    g2.set(ylim=(0, None))
    g2.set_titles("Model: {col_name}")
    g2.tight_layout(rect=[0, 0, 1, 0.96])

    output_path = os.path.join(output_dir, 'toxicity_by_model.png')
    save_figure(g2.fig, output_path)
    plt.close(g2.fig)

    print("\n--- Generating Plot 3: Response Politeness Score ---")
    # Plot 3: Politeness Score of Response
    g3 = sns.relplot(
        data=df_filtered,
        x='TaskNumber',
        y='Response_ValidatedPolitenessScore',
        hue='PromptTone',
        col='Model',
        kind='line',
        marker='o',
        height=6,
        aspect=1.2,
        col_wrap=2,
        palette='mako'
    )
    g3.fig.suptitle('3) Response Politeness Score by Model and Prompt Tone', y=1.03, fontsize=22)
    g3.set_axis_labels("Task Number", "Politeness Score")
    g3.set_titles("Model: {col_name}")
    g3.tight_layout(rect=[0, 0, 1, 0.96])

    output_path = os.path.join(output_dir, 'politeness_by_model.png')
    save_figure(g3.fig, output_path)
    plt.close(g3.fig)

    print("\n--- Generating Plot 4: Response Length ---")
    # Plot 4: Response Length
    g4 = sns.relplot(
        data=df_filtered,
        x='TaskNumber',
        y='ResponseLength',
        hue='PromptTone',
        col='Model',
        kind='line',
        marker='o',
        height=6,
        aspect=1.2,
        col_wrap=2,
        palette='flare'
    )
    g4.fig.suptitle('4) Response Length by Model and Prompt Tone', y=1.03, fontsize=22)
    g4.set_axis_labels("Task Number", "Length (Number of Characters)")
    g4.set_titles("Model: {col_name}")
    g4.tight_layout(rect=[0, 0, 1, 0.96])

    output_path = os.path.join(output_dir, 'response_length_by_model.png')
    save_figure(g4.fig, output_path)
    plt.close(g4.fig)

def print_model_statistics(df):
    """Print statistics by model"""
    df_filtered = df[df['PromptTone'].isin(['Polite', 'Threatening'])]

    print("\n" + "="*60)
    print("MODEL-SPECIFIC STATISTICS")
    print("="*60)

    for model in df_filtered['Model'].unique():
        model_data = df_filtered[df_filtered['Model'] == model]
        print(f"\n--- {model} ---")
        print("Sentiment Score:")
        print(model_data.groupby('PromptTone')['Response_SentimentScore'].agg(['mean', 'std', 'count']))
        print("Toxicity Score:")
        print(model_data.groupby('PromptTone')['RoBERTa_Response_ToxicityScore'].agg(['mean', 'std', 'count']))

def main():
    """Main execution function"""
    script_dir = os.path.dirname(__file__)
    dataset_path = os.path.join(script_dir, '..', '..', 'final_dataset.csv')

    df = load_dataset(dataset_path)
    if df is None:
        return

    print("Starting Faceted Model Analysis...")

    # Create output directory
    output_dir = os.path.dirname(__file__)

    # Generate plots
    create_faceted_analysis(df, output_dir)

    # Print statistics
    print_model_statistics(df)

    print("\nFaceted Model Analysis completed!")

if __name__ == "__main__":
    main()