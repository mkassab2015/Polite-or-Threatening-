# Capstone Analysis Suite

This repository contains a comprehensive analysis of AI model responses to different prompt tones, split from a Jupyter notebook into modular, reusable Python scripts.

## 🚀 Quick Start

To run all analyses:

```bash
python3 run_all_analyses.py
```

To run individual analyses:

```bash
cd 01_basic_stripplots
python3 basic_stripplot_analysis.py
```

## 📊 Analysis Overview

### Research Question
How do different AI models respond to polite versus threatening prompts across multiple behavioral metrics?

### Dataset
- **File**: `final_dataset.csv`
- **Size**: 483 responses
- **Models**: GPT-4o, Claude Sonnet 4, Gemini 2.5 Pro, DeepSeek Chat
- **Conditions**: Polite vs. Threatening prompts (240 responses each)
- **Metrics**: Sentiment Score, Toxicity Score, Politeness Score, Response Length

## 📁 Directory Structure

```
capstone_analysis/
├── 01_basic_stripplots/           # Foundational stripplot analysis
├── 02_faceted_by_model/           # Model-specific comparative analysis
├── 03_categorical_distributions/  # Categorical analysis of response metrics
├── 04_paired_comparison/          # Direct paired response comparisons
├── 05_politeness_strategies/      # Detailed politeness strategy analysis
├── 07_raincloud_distributions/    # Statistical testing with raincloud plots
├── 08_cross_context_analysis/     # Cross-model and cross-task comparisons
├── 09_safety_behaviors/           # AI safety and defensive behavior analysis
├── 12_model_comprehensive/        # Comprehensive model-specific analysis
├── 13_task_comprehensive/         # Comprehensive task-category analysis
├── 14_response_length/            # Response verbosity and length analysis
├── shared/                        # Common utilities and plotting functions
├── run_all_analyses.py           # Master script to run all analyses
└── README.md                     # This file
```

## 📈 Analysis Details

### 1. Basic Stripplot Analysis (`01_basic_stripplots/`)
**Purpose**: Foundational comparison of AI responses across four key metrics
- Creates 2x2 grid of stripplots
- Compares polite vs. threatening prompt responses
- **Generated**: `basic_stripplot_analysis.png`

### 2. Faceted Model Analysis (`02_faceted_by_model/`)
**Purpose**: Model-specific response patterns over time/tasks
- Separate line plots for each AI model
- Shows trends across task numbers
- **Generated**: 4 PNG files (sentiment, toxicity, politeness, response length by model)

### 3. Categorical Distributions Analysis (`03_categorical_distributions/`)
**Purpose**: Transforms continuous metrics into interpretable categories
- VADER sentiment categories (Negative/Neutral/Positive)
- RoBERTa toxicity levels (Very Low to Very High)
- Politeness categories (Very Impolite to Very Polite)
- **Generated**: `categorical_distributions_analysis.png`

### 4. Paired Comparison Analysis (`04_paired_comparison/`)
**Purpose**: Direct comparison of responses to identical tasks with different prompt tones
- Scatter plots with diagonal reference lines
- Emphasizes experimental paired design
- **Generated**: `paired_comparison_analysis.png`

### 5. Politeness Strategy Analysis (`05_politeness_strategies/`)
**Purpose**: Examines specific politeness strategies used in responses
- Bar charts of strategy frequency by prompt tone
- Identifies most common politeness mechanisms
- **Generated**: `politeness_strategy_analysis.png`

### 6. Raincloud Distributions Analysis (`07_raincloud_distributions/`)
**Purpose**: Statistical testing combined with comprehensive distribution visualization
- Paired t-tests for statistical significance
- Raincloud plots (strip + violin + box plots)
- **Generated**: `raincloud_distributions.png`

### 7. Cross-Context Analysis (`08_cross_context_analysis/`)
**Purpose**: Compare sensitivity across different AI models and task categories
- Point plots with confidence intervals
- Model and task category sensitivity rankings
- **Generated**: `cross_context_analysis.png`

### 8. Safety Behavior Analysis (`09_safety_behaviors/`)
**Purpose**: Analyzes potential AI safety and defensive behaviors
- Examines response length, toxicity, and sentiment as safety indicators
- Identifies potential refusal or cautious behavior patterns
- **Generated**: `safety_behavior_analysis.png`

### 9. Model Comprehensive Analysis (`12_model_comprehensive/`)
**Purpose**: In-depth model-specific analysis across four dimensions
- Sentiment category distributions by model
- Toxicity proportions by model
- Politeness metrics and feature counts by model
- Top politeness strategy usage by model
- **Generated**: 4 PNG files (sentiment, toxicity, politeness, strategies by model)

### 10. Task Comprehensive Analysis (`13_task_comprehensive/`)
**Purpose**: In-depth task-category-specific analysis across four dimensions
- Sentiment category distributions by task type
- Toxicity proportions by task type
- Politeness metrics and feature counts by task type
- Top politeness strategy usage by task type
- **Generated**: 4 PNG files (sentiment, toxicity, politeness, strategies by task)

### 11. Response Length Analysis (`14_response_length/`)
**Purpose**: Detailed analysis of response verbosity patterns
- Statistical testing of length differences
- Model-specific length patterns
- **Generated**: `response_length_analysis.png`

## 🔧 Technical Details

### Dependencies
- pandas
- matplotlib
- seaborn
- scipy (for statistical tests)
- numpy

### Features
- **Non-interactive plotting**: Uses Agg backend for headless execution
- **Modular design**: Shared utilities in `shared/` directory
- **Error handling**: Comprehensive error checking and reporting
- **Statistical analysis**: Includes t-tests, effect sizes, and descriptive statistics

### File Structure
Each analysis directory contains:
- `*.py`: Main analysis script
- `README.md`: Detailed explanation of the analysis
- `*.png`: Generated visualization files

## 📊 Key Findings Summary

### Response Patterns by Prompt Tone:
- **Sentiment**: Polite prompts: 0.789, Threatening prompts: 0.532 (significant difference)
- **Toxicity**: Minimal difference between conditions (both very low)
- **Politeness**: Slight decrease with threatening prompts (4.85 → 4.70)
- **Length**: Shorter responses to threatening prompts (1472 → 1249 chars, p=0.022)

### Model-Specific Insights:
- **GPT-4o**: Most consistent across prompt tones
- **Claude Sonnet 4**: Largest sentiment difference between conditions
- **DeepSeek Chat**: Most dramatic sentiment drop with threatening prompts
- **Gemini 2.5 Pro**: Moderate sensitivity across all metrics

### Safety Behaviors:
- 20.4% negative sentiment responses to threatening vs 8.8% to polite
- 3.8% high toxicity responses to threatening vs 2.5% to polite
- Consistent trend toward more defensive/cautious responses

## 🎯 Usage Scenarios

1. **Academic Research**: Understanding AI behavior under different prompt conditions
2. **Safety Evaluation**: Assessing AI robustness to adversarial prompts
3. **Model Comparison**: Benchmarking different AI models' behavioral patterns
4. **Prompt Engineering**: Informing best practices for prompt design

## 📝 Documentation

Each analysis directory contains detailed README files explaining:
- Purpose and methodology
- Visualization interpretation
- Expected patterns and research questions
- Files generated and their meaning

## 🔬 Statistical Rigor

- **Paired Design**: Utilizes the paired nature of the experimental design
- **Effect Sizes**: Includes Cohen's d for practical significance
- **Multiple Metrics**: Comprehensive behavioral assessment
- **Model Comparison**: Systematic comparison across AI systems

---

**Generated from Jupyter notebook**: `capstone_expirement_graphs.ipynb`
**Dataset**: `final_dataset.csv`
**Total Analyses**: 11 completed successfully
**Generated Visualizations**: 21 PNG files