# Raincloud Distributions Analysis

## Overview
This analysis combines statistical hypothesis testing with advanced raincloud visualizations that layer strip plots, violin plots, and box plots to provide comprehensive distribution insights.

## What This Analysis Shows

### Statistical Testing Component
- **Paired T-Tests**: Compares polite vs. threatening responses for the same tasks
- **Multiple Metrics**: Tests sentiment, toxicity, and politeness scores
- **Effect Significance**: Determines statistical significance (p < 0.05)
- **Mean Comparisons**: Reports average scores for each condition

### Raincloud Visualization Component

#### 1. Response Sentiment Score Distribution
- **Strip Plot Layer**: Shows individual response points with jitter
- **Violin Plot Layer**: Displays probability density of score distributions
- **Box Plot Layer**: Highlights median, quartiles, and outliers
- **Key Insight**: Reveals the full shape of sentiment distributions

#### 2. Response Toxicity Score Distribution
- **Layered Visualization**: Same three-layer approach as sentiment
- **Y-axis Constraint**: Starts at 0 since toxicity scores are non-negative
- **Key Insight**: Shows whether threatening prompts create more toxic response distributions

#### 3. Response Politeness Score Distribution
- **Comprehensive View**: Individual points + distribution shape + statistical summary
- **Full Scale Display**: Shows complete 1-5 politeness scale
- **Key Insight**: Demonstrates politeness distribution differences between conditions

## Methodology
- **Paired Design**: Uses same tasks across both prompt conditions
- **Statistical Rigor**: Performs related-samples t-tests for proper comparison
- **Layered Visualization**: Combines three complementary plot types
- **Transparency Control**: Uses alpha values to show overlapping information

## Statistical Output
For each metric, the analysis reports:
- **Mean Scores**: Average values for polite and threatening conditions
- **T-Statistic**: Measure of difference magnitude relative to variability
- **P-Value**: Probability of observing difference by chance
- **Significance**: Clear interpretation of statistical results

## Raincloud Plot Interpretation

### Strip Plot Layer (Individual Points)
- **Gray Dots**: Each represents one AI response
- **Jitter**: Horizontal spreading prevents overlap
- **Shows**: Raw data distribution and outliers

### Violin Plot Layer (Distribution Shape)
- **Color**: Metric-specific color scheme
- **Width**: Indicates probability density at each score level
- **Shows**: Whether distributions are normal, skewed, or multi-modal

### Box Plot Layer (Statistical Summary)
- **White Line**: Median (50th percentile)
- **Box**: Interquartile range (25th-75th percentiles)
- **Whiskers**: Data range excluding outliers
- **Shows**: Central tendency and spread

## Files Generated
- `raincloud_distributions.png`: Three-panel raincloud visualization
- Console output with detailed statistical test results

## Advantages of Raincloud Plots
1. **Complete Information**: Shows raw data, distribution shape, and summary statistics
2. **Outlier Detection**: Individual points reveal extreme responses
3. **Distribution Shape**: Violin plots show skewness, multimodality, or other patterns
4. **Statistical Summary**: Box plots provide familiar quartile information
5. **Comparative Analysis**: Easy visual comparison between prompt conditions

## Research Applications
- **Statistical Validation**: Provides rigorous hypothesis testing
- **Distribution Analysis**: Reveals non-normal or unusual response patterns
- **Outlier Investigation**: Identifies extreme responses for further analysis
- **Publication Quality**: Professional visualizations suitable for academic papers

This analysis combines the rigor of inferential statistics with the richness of exploratory data visualization to provide comprehensive insights into AI response distributions.