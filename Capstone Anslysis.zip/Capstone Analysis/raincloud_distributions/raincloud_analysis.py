#!/usr/bin/env python3
"""
Raincloud Distributions Analysis
=================================

This script performs statistical tests and creates raincloud plots that combine
strip plots, violin plots, and box plots for comprehensive distribution analysis.
"""

import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'shared'))

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
from scipy import stats
from data_loader import load_dataset
from plotting_utils import setup_plot_style, save_figure

warnings.filterwarnings('ignore')

def perform_statistical_tests(df_filtered):
    """Perform paired t-tests on the data"""
    print("\n--- Performing Paired T-Tests (Threatening vs. Polite Responses) ---")

    # Reshape data for paired analysis
    df_pivot = df_filtered.pivot_table(
        index=['TaskID', 'Model'],
        columns='PromptTone',
        values=['Response_SentimentScore', 'RoBERTa_Response_ToxicityScore', 'Response_ValidatedPolitenessScore']
    )
    df_pivot.columns = ['_'.join(col).strip() for col in df_pivot.columns.values]
    df_pivot.dropna(inplace=True)

    metrics_to_test = {
        'Sentiment': ('Response_SentimentScore_Polite', 'Response_SentimentScore_Threatening'),
        'Toxicity': ('RoBERTa_Response_ToxicityScore_Polite', 'RoBERTa_Response_ToxicityScore_Threatening'),
        'Politeness': ('Response_ValidatedPolitenessScore_Polite', 'Response_ValidatedPolitenessScore_Threatening')
    }

    results = {}
    for metric_name, (polite_col, threatening_col) in metrics_to_test.items():
        if polite_col in df_pivot.columns and threatening_col in df_pivot.columns:
            t_stat, p_value = stats.ttest_rel(df_pivot[polite_col], df_pivot[threatening_col])

            results[metric_name] = {
                'mean_polite': df_pivot[polite_col].mean(),
                'mean_threatening': df_pivot[threatening_col].mean(),
                't_stat': t_stat,
                'p_value': p_value
            }

            print(f"\nResults for {metric_name}:")
            print(f"  Mean Polite Score: {results[metric_name]['mean_polite']:.3f}")
            print(f"  Mean Threatening Score: {results[metric_name]['mean_threatening']:.3f}")
            print(f"  T-statistic: {t_stat:.3f}")
            print(f"  P-value: {p_value:.5f}")
            if p_value < 0.05:
                print("  Result: The difference is statistically significant.")
            else:
                print("  Result: The difference is not statistically significant.")
        else:
            print(f"\nCould not perform t-test for {metric_name}: one or both columns not found.")

    return results

def create_raincloud_plots(df, output_dir='.'):
    """Create raincloud plots combining multiple visualization types"""

    df_filtered = df[df['PromptTone'].isin(['Polite', 'Threatening'])].copy()

    # Set up plotting
    setup_plot_style()
    sns.set_theme(style="whitegrid", context="talk")
    fig, axes = plt.subplots(1, 3, figsize=(24, 8))
    fig.suptitle('Distribution of Response Metrics by Prompt Tone', fontsize=28, y=1.05)

    plot_order = ['Polite', 'Threatening']
    palettes = {'Sentiment': 'viridis', 'Toxicity': 'rocket', 'Politeness': 'mako'}
    metrics = {
        'Sentiment': 'Response_SentimentScore',
        'Toxicity': 'RoBERTa_Response_ToxicityScore',
        'Politeness': 'Response_ValidatedPolitenessScore'
    }
    titles = {
        'Sentiment': 'A) Response Sentiment Score',
        'Toxicity': 'B) Response Toxicity Score',
        'Politeness': 'C) Response Politeness Score'
    }

    for i, (metric_name, col_name) in enumerate(metrics.items()):
        ax = axes[i]

        # Layer 1: Strip plot (individual points)
        sns.stripplot(data=df_filtered, x='PromptTone', y=col_name, ax=ax, order=plot_order,
                     jitter=0.2, alpha=0.25, color='grey', size=5)

        # Layer 2: Violin plot (distribution shape)
        sns.violinplot(data=df_filtered, x='PromptTone', y=col_name, ax=ax, order=plot_order,
                      palette=palettes[metric_name], inner=None, cut=0, density_norm='width',
                      linewidth=2, saturation=0.7)

        # Layer 3: Box plot (quartiles and median)
        sns.boxplot(data=df_filtered, x='PromptTone', y=col_name, ax=ax, order=plot_order,
                   width=0.2, boxprops={'zorder': 2, 'alpha': 0.8}, saturation=0.7,
                   whiskerprops={'linewidth': 2, 'zorder': 2},
                   capprops={'zorder': 2},
                   medianprops={'color':'white', 'linewidth':2, 'zorder':3},
                   palette=palettes[metric_name])

        ax.set_title(titles[metric_name], fontsize=20)
        ax.set_xlabel('Prompt Tone', fontsize=16)
        ax.set_ylabel('Score', fontsize=16)

        if metric_name == 'Toxicity':
            ax.set_ylim(bottom=0)

    plt.tight_layout(rect=[0, 0.03, 1, 0.95])

    # Save the figure
    output_path = os.path.join(output_dir, 'raincloud_distributions.png')
    save_figure(fig, output_path)
    plt.close(fig)

def main():
    """Main execution function"""
    script_dir = os.path.dirname(__file__)
    dataset_path = os.path.join(script_dir, '..', '..', 'final_dataset.csv')

    df = load_dataset(dataset_path)
    if df is None:
        return

    print("Starting Raincloud Distributions Analysis...")

    output_dir = os.path.dirname(__file__)

    # Filter data
    df_filtered = df[df['PromptTone'].isin(['Polite', 'Threatening'])].copy()

    # Perform statistical tests
    results = perform_statistical_tests(df_filtered)

    # Generate raincloud plots
    create_raincloud_plots(df, output_dir)

    print("\nRaincloud Distributions Analysis completed!")

if __name__ == "__main__":
    main()