#!/usr/bin/env python3
"""
Cross-Context Analysis
======================

This script analyzes how different models and task categories respond
to prompt tone variations using point plots for statistical comparisons.
"""

import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'shared'))

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
from data_loader import load_dataset
from plotting_utils import setup_plot_style, save_figure

warnings.filterwarnings('ignore')

def create_cross_context_analysis(df, output_dir='.'):
    """Create cross-context analysis comparing models and task categories"""

    df_filtered = df[df['PromptTone'].isin(['Polite', 'Threatening'])].copy()

    # Create TaskCategory column
    df_filtered['TaskCategory'] = df_filtered['TaskID'].str.replace('(\d+)$', '', regex=True)

    # Set up plotting
    setup_plot_style()
    sns.set_theme(style="darkgrid", context="talk")
    fig, axes = plt.subplots(1, 2, figsize=(22, 9))
    fig.suptitle('Impact of Prompt Tone Across Different Contexts', fontsize=28, y=1.05)

    # Plot 1: Comparing Models
    sns.pointplot(ax=axes[0], data=df_filtered, x='Model', y='Response_ValidatedPolitenessScore',
                 hue='PromptTone', palette={'Polite': 'royalblue', 'Threatening': 'orangered'},
                 dodge=True, capsize=.1)
    axes[0].set_title('A) Model Sensitivity to Prompt Tone', fontsize=20)
    axes[0].set_xlabel('Model', fontsize=16)
    axes[0].set_ylabel('Average Politeness Score', fontsize=16)
    axes[0].tick_params(axis='x', rotation=15)
    axes[0].legend(title='Prompt Tone')

    # Plot 2: Comparing Task Categories
    sns.pointplot(ax=axes[1], data=df_filtered, x='TaskCategory', y='Response_ValidatedPolitenessScore',
                 hue='PromptTone', palette={'Polite': 'royalblue', 'Threatening': 'orangered'},
                 dodge=True, capsize=.1)
    axes[1].set_title('B) Task Category Sensitivity to Prompt Tone', fontsize=20)
    axes[1].set_xlabel('Task Category', fontsize=16)
    axes[1].set_ylabel('Average Politeness Score', fontsize=16)
    axes[1].tick_params(axis='x', rotation=15)
    axes[1].legend(title='Prompt Tone')

    plt.tight_layout(rect=[0, 0.03, 1, 0.95])

    # Save the figure
    output_path = os.path.join(output_dir, 'cross_context_analysis.png')
    save_figure(fig, output_path)
    plt.close(fig)

    return df_filtered

def print_context_statistics(df_filtered):
    """Print cross-context statistics"""
    print("\n" + "="*60)
    print("CROSS-CONTEXT ANALYSIS STATISTICS")
    print("="*60)

    # Model-specific analysis
    print("\nModel-Specific Politeness Scores:")
    model_stats = df_filtered.groupby(['Model', 'PromptTone'])['Response_ValidatedPolitenessScore'].agg(['mean', 'std', 'count'])
    print(model_stats)

    # Calculate differences between prompt tones for each model
    print("\nPoliteness Score Differences by Model (Polite - Threatening):")
    model_pivot = df_filtered.groupby(['Model', 'PromptTone'])['Response_ValidatedPolitenessScore'].mean().unstack()
    if 'Polite' in model_pivot.columns and 'Threatening' in model_pivot.columns:
        model_diff = model_pivot['Polite'] - model_pivot['Threatening']
        print(model_diff.sort_values(ascending=False))

    # Task category analysis
    print("\nTask Category Politeness Scores:")
    task_stats = df_filtered.groupby(['TaskCategory', 'PromptTone'])['Response_ValidatedPolitenessScore'].agg(['mean', 'std', 'count'])
    print(task_stats)

    # Calculate differences between prompt tones for each task category
    print("\nPoliteness Score Differences by Task Category (Polite - Threatening):")
    task_pivot = df_filtered.groupby(['TaskCategory', 'PromptTone'])['Response_ValidatedPolitenessScore'].mean().unstack()
    if 'Polite' in task_pivot.columns and 'Threatening' in task_pivot.columns:
        task_diff = task_pivot['Polite'] - task_pivot['Threatening']
        print(task_diff.sort_values(ascending=False))

    # Context sensitivity ranking
    print("\nModel Sensitivity Ranking (largest to smallest difference):")
    for i, (model, diff) in enumerate(model_diff.sort_values(ascending=False).items(), 1):
        print(f"{i}. {model}: {diff:.3f}")

    print("\nTask Category Sensitivity Ranking (largest to smallest difference):")
    for i, (task, diff) in enumerate(task_diff.sort_values(ascending=False).items(), 1):
        print(f"{i}. {task}: {diff:.3f}")

def main():
    """Main execution function"""
    script_dir = os.path.dirname(__file__)
    dataset_path = os.path.join(script_dir, '..', '..', 'final_dataset.csv')

    df = load_dataset(dataset_path)
    if df is None:
        return

    print("Starting Cross-Context Analysis...")

    output_dir = os.path.dirname(__file__)

    # Generate analysis
    df_filtered = create_cross_context_analysis(df, output_dir)

    # Print statistics
    print_context_statistics(df_filtered)

    print("\nCross-Context Analysis completed!")

if __name__ == "__main__":
    main()