#!/usr/bin/env python3
"""
Task Comprehensive Analysis
===========================

This script provides an in-depth, task-category-specific analysis across four dimensions:
1. Sentiment category distributions by task type
2. Toxicity proportions by task type
3. Politeness scores and feature counts by task type
4. Top politeness strategy usage patterns by task type
"""

import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'shared'))

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
from collections import defaultdict
from data_loader import load_dataset
from plotting_utils import setup_plot_style, save_figure

warnings.filterwarnings('ignore')

def get_task_category(task_id):
    """Extract task category from TaskID"""
    if task_id.startswith('ProgrammingHelp'):
        return 'Programming Help'
    elif task_id.startswith('EthicalDilemma'):
        return 'Ethical Dilemma'
    elif task_id.startswith('WritingTask'):
        return 'Writing Task'
    elif task_id.startswith('PolicyAdvice'):
        return 'Policy Advice'
    return 'Other'

def create_task_comprehensive_analysis(df, output_dir='.'):
    """Create comprehensive task-category-specific analysis with four sub-analyses"""

    df_filtered = df[df['PromptTone'].isin(['Polite', 'Threatening'])].copy()

    # Create the 'TaskCategory' column
    df_filtered['TaskCategory'] = df_filtered['TaskID'].apply(get_task_category)

    # Define the order for the plots
    category_order = ['Programming Help', 'Ethical Dilemma', 'Writing Task', 'Policy Advice']

    # Set theme for all plots
    setup_plot_style()
    sns.set_theme(style="whitegrid", context="talk")
    tone_palette = {'Polite': 'royalblue', 'Threatening': 'orangered'}

    # --- Analysis 1: Sentiment Score Distribution by Task Category ---
    print("\n--- Generating Plot 1: Sentiment Score Analysis by Task Category ---")
    df_filtered['SentimentCategory'] = pd.cut(
        df_filtered['Response_SentimentScore'],
        bins=[-float('inf'), -0.05, 0.05, float('inf')],
        labels=['Negative', 'Neutral', 'Positive'],
        right=False
    )

    g1 = sns.catplot(
        data=df_filtered,
        x='SentimentCategory',
        hue='PromptTone',
        col='TaskCategory',
        kind='count',
        col_wrap=2,
        height=7,
        aspect=1.2,
        palette=tone_palette,
        order=['Negative', 'Neutral', 'Positive'],
        col_order=category_order,
        legend_out=False
    )
    g1.fig.suptitle('1) Distribution of Response Sentiment Categories by Task Type', y=1.03, fontsize=24)
    g1.set_axis_labels("Sentiment Category (VADER)", "Count of Responses")
    g1.set_titles("Task Category: {col_name}")
    g1.add_legend(title='Prompt Tone')

    # Add count annotations to each bar
    for ax in g1.axes.flatten():
        for p in ax.patches:
            if p.get_height() > 0:
                ax.annotate(f'{int(p.get_height())}',
                           (p.get_x() + p.get_width() / 2., p.get_height()),
                           ha='center', va='center', xytext=(0, 9),
                           textcoords='offset points', fontsize=14)

    plt.tight_layout(rect=[0, 0, 1, 0.96])

    output_path = os.path.join(output_dir, 'sentiment_categories_by_task.png')
    save_figure(g1.fig, output_path)
    plt.close(g1.fig)

    # --- Analysis 2: Toxicity Score Proportions by Task Category ---
    print("\n--- Generating Plot 2: Toxicity Score Analysis by Task Category ---")
    toxicity_labels = ['Very Low', 'Low', 'Moderate', 'High', 'Very High']
    df_filtered['ToxicityCategory'] = pd.cut(
        df_filtered['RoBERTa_Response_ToxicityScore'],
        bins=[-float('inf'), 0.1, 0.3, 0.5, 0.7, float('inf')],
        labels=toxicity_labels,
        right=False
    )
    df_filtered['ToxicityCategory'] = pd.Categorical(df_filtered['ToxicityCategory'], categories=toxicity_labels, ordered=True)

    toxicity_proportions = df_filtered.groupby(['TaskCategory', 'PromptTone'])['ToxicityCategory'].value_counts(normalize=True).mul(100).rename('Percentage').reset_index()

    g2 = sns.catplot(
        data=toxicity_proportions,
        x='PromptTone',
        y='Percentage',
        hue='ToxicityCategory',
        col='TaskCategory',
        kind='bar',
        col_wrap=2,
        height=7,
        aspect=1.2,
        palette='rocket_r',
        col_order=category_order,
        legend_out=False
    )
    g2.fig.suptitle('2) Proportional Distribution of Response Toxicity by Task Type', y=1.03, fontsize=24)
    g2.set_axis_labels("Prompt Tone", "Percentage of Responses (%)")
    g2.set_titles("Task Category: {col_name}")
    g2.add_legend(title='Toxicity Category')
    plt.tight_layout(rect=[0, 0, 1, 0.96])

    output_path = os.path.join(output_dir, 'toxicity_proportions_by_task.png')
    save_figure(g2.fig, output_path)
    plt.close(g2.fig)

    # --- Analysis 3: Politeness Score and Feature Count by Task Category ---
    print("\n--- Generating Plot 3: Politeness Score & Feature Count Analysis by Task Category ---")
    politeness_melted = df_filtered.melt(
        id_vars=['TaskCategory', 'PromptTone'],
        value_vars=['Response_ValidatedPolitenessScore', 'Response_ValidatedFeatureCount'],
        var_name='MetricType',
        value_name='Value'
    )
    politeness_melted['MetricType'] = politeness_melted['MetricType'].replace({
        'Response_ValidatedPolitenessScore': 'Politeness Score (1-5)',
        'Response_ValidatedFeatureCount': 'Politeness Feature Count'
    })

    g3 = sns.catplot(
        data=politeness_melted,
        x='MetricType',
        y='Value',
        hue='PromptTone',
        col='TaskCategory',
        kind='point',
        col_wrap=2,
        height=7,
        aspect=1.2,
        palette=tone_palette,
        col_order=category_order,
        dodge=0.3,
        capsize=0.1,
        legend_out=False
    )
    g3.fig.suptitle('3) Average Politeness Score vs. Feature Count by Task Type', y=1.03, fontsize=24)
    g3.set_axis_labels("Metric", "Average Value")
    g3.set_titles("Task Category: {col_name}")
    g3.add_legend(title='Prompt Tone')
    plt.tight_layout(rect=[0, 0, 1, 0.96])

    output_path = os.path.join(output_dir, 'politeness_metrics_by_task.png')
    save_figure(g3.fig, output_path)
    plt.close(g3.fig)

    # --- Analysis 4: Politeness Strategy Breakdown by Task Category ---
    print("\n--- Generating Plot 4: Politeness Strategy Breakdown Analysis by Task Category ---")
    strategy_data = []
    for index, row in df_filtered.iterrows():
        strategies_str = row['Response_ValidatedStrategies']
        if pd.notna(strategies_str):
            strategies = strategies_str.split('; ')
            for strategy in strategies:
                parts = strategy.split(':')
                if len(parts) == 2:
                    try:
                        strategy_data.append({
                            'TaskCategory': row['TaskCategory'],
                            'PromptTone': row['PromptTone'],
                            'Strategy': parts[0].strip(),
                            'Count': int(parts[1].strip())
                        })
                    except ValueError:
                        continue
    df_strategies = pd.DataFrame(strategy_data)

    top_strategies = df_strategies.groupby('Strategy')['Count'].sum().nlargest(5).index.tolist()
    df_top_strategies = df_strategies[df_strategies['Strategy'].isin(top_strategies)]

    g4 = sns.catplot(
        data=df_top_strategies,
        x='Strategy',
        y='Count',
        hue='PromptTone',
        col='TaskCategory',
        kind='bar',
        col_wrap=2,
        height=7,
        aspect=1.2,
        palette=tone_palette,
        order=top_strategies,
        col_order=category_order,
        estimator=sum,
        ci=None,
        legend_out=False
    )
    g4.fig.suptitle('4) Usage of Top 5 Politeness Strategies by Task Type', y=1.03, fontsize=24)
    g4.set_axis_labels("Politeness Strategy", "Total Times Strategy Was Used")
    g4.set_titles("Task Category: {col_name}")
    g4.add_legend(title='Prompt Tone')
    plt.tight_layout(rect=[0, 0, 1, 0.96])

    output_path = os.path.join(output_dir, 'strategy_usage_by_task.png')
    save_figure(g4.fig, output_path)
    plt.close(g4.fig)

    return df_filtered, df_strategies

def print_comprehensive_task_statistics(df_filtered, df_strategies):
    """Print detailed task-category-specific statistics"""
    print("\n" + "="*60)
    print("TASK COMPREHENSIVE ANALYSIS STATISTICS")
    print("="*60)

    # Sentiment analysis by task category
    print("\nSentiment Categories by Task Category:")
    sentiment_crosstab = pd.crosstab([df_filtered['TaskCategory'], df_filtered['SentimentCategory']],
                                   df_filtered['PromptTone'], margins=True)
    print(sentiment_crosstab)

    # Toxicity analysis by task category
    print("\nToxicity Categories by Task Category:")
    toxicity_crosstab = pd.crosstab([df_filtered['TaskCategory'], df_filtered['ToxicityCategory']],
                                  df_filtered['PromptTone'], margins=True)
    print(toxicity_crosstab)

    # Politeness metrics by task category
    print("\nPoliteness Metrics by Task Category:")
    politeness_stats = df_filtered.groupby(['TaskCategory', 'PromptTone'])[
        ['Response_ValidatedPolitenessScore', 'Response_ValidatedFeatureCount']
    ].agg(['mean', 'std'])
    print(politeness_stats)

    # Strategy usage by task category
    print("\nTop Strategy Usage by Task Category:")
    strategy_summary = df_strategies.groupby(['TaskCategory', 'PromptTone', 'Strategy'])['Count'].sum().reset_index()
    top_strategies_by_task = strategy_summary.groupby('TaskCategory').apply(
        lambda x: x.nlargest(3, 'Count')
    ).reset_index(drop=True)
    print(top_strategies_by_task)

    # Task category sensitivity analysis
    print("\nTask Category Sensitivity (Polite vs Threatening Differences):")
    sensitivity_analysis = df_filtered.groupby(['TaskCategory', 'PromptTone'])[
        ['Response_SentimentScore', 'RoBERTa_Response_ToxicityScore', 'Response_ValidatedPolitenessScore']
    ].mean().unstack()

    for metric in ['Response_SentimentScore', 'RoBERTa_Response_ToxicityScore', 'Response_ValidatedPolitenessScore']:
        print(f"\n{metric} Differences (Polite - Threatening):")
        differences = sensitivity_analysis[metric]['Polite'] - sensitivity_analysis[metric]['Threatening']
        print(differences.sort_values(ascending=False))

def main():
    """Main execution function"""
    script_dir = os.path.dirname(__file__)
    dataset_path = os.path.join(script_dir, '..', '..', 'final_dataset.csv')

    df = load_dataset(dataset_path)
    if df is None:
        return

    print("Starting Task Comprehensive Analysis...")

    output_dir = os.path.dirname(__file__)

    # Generate comprehensive analysis
    df_filtered, df_strategies = create_task_comprehensive_analysis(df, output_dir)

    # Print statistics
    print_comprehensive_task_statistics(df_filtered, df_strategies)

    print("\nTask Comprehensive Analysis completed!")

if __name__ == "__main__":
    main()