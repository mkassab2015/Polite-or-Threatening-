# Politeness Strategy Analysis

## Overview
This analysis examines the specific politeness strategies employed by AI models in their responses and compares their usage between polite and threatening prompts.

## What This Analysis Shows

### 1. Strategy Frequency by Prompt Tone
- **Purpose**: Identify which specific politeness strategies are most commonly used
- **Visualization**: Bar chart showing top 15 strategies with separate bars for each prompt tone
- **Key Insight**: Reveals whether certain strategies are preferred for different prompt tones

### 2. Politeness Score Distribution
- **Purpose**: Show the overall distribution of politeness scores by prompt tone
- **Visualization**: Box plots comparing score distributions
- **Key Insight**: Demonstrates the range and central tendency of politeness across prompt types

## Methodology
- **Strategy Parsing**: Extracts individual strategies from the `Response_ValidatedStrategies` field
- **Data Explosion**: Creates separate rows for each strategy occurrence
- **Frequency Analysis**: Counts strategy usage across different prompt tones
- **Statistical Comparison**: Identifies strategies that differ significantly between conditions

## Key Features
- **Top Strategy Identification**: Focuses on the 15 most frequently used strategies
- **Comparative Analysis**: Side-by-side comparison of strategy usage
- **Distribution Visualization**: Box plots show score variability
- **Difference Quantification**: Calculates which strategies are more/less common per tone

## Expected Politeness Strategies
Common strategies that might appear include:
- **Please/Thank you**: Direct politeness markers
- **Hedging**: Softening statements ("perhaps", "might")
- **Indirect requests**: Avoiding direct commands
- **Apologizing**: Using apologies or disclaimers
- **Gratitude**: Expressing appreciation
- **Deference**: Showing respect or acknowledgment

## Files Generated
- `politeness_strategy_analysis.png`: Combined strategy frequency and score distribution plots
- Console output with detailed strategy statistics and comparisons

## Interpretation Guide
- **Higher Bars**: Indicate more frequent strategy usage
- **Side-by-side Comparison**: Shows how strategy usage differs between prompt tones
- **Box Plot Insights**:
  - Center line shows median politeness
  - Box shows interquartile range
  - Whiskers show data range
  - Outliers appear as individual points
- **Strategy Differences**: Positive differences indicate more usage with threatening prompts

## Research Questions Addressed
1. Do AI models use different politeness strategies when responding to threatening vs. polite prompts?
2. Which specific strategies are most robust across different prompt tones?
3. Are there strategies that appear uniquely in response to certain prompt tones?
4. How much variability exists in politeness strategy selection?

This analysis provides granular insights into how AI models adapt their communication style and reveals the specific linguistic strategies employed to maintain politeness under different conditions.