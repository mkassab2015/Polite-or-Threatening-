#!/usr/bin/env python3
"""
Politeness Strategy Analysis
============================

This script analyzes the specific politeness strategies used in AI responses
and compares their frequency between polite and threatening prompts.
"""

import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'shared'))

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import ast
from data_loader import load_dataset
from plotting_utils import setup_plot_style, save_figure

def parse_strategies(strategy_string):
    """Parse strategy string into list of strategies"""
    if pd.isna(strategy_string):
        return []
    try:
        # Try to evaluate as literal
        parsed = ast.literal_eval(strategy_string)
        if isinstance(parsed, list):
            return parsed
        else:
            return [parsed]
    except:
        # If that fails, treat as string and split
        if isinstance(strategy_string, str):
            return [s.strip() for s in strategy_string.split(',') if s.strip()]
        return []

def create_politeness_strategy_analysis(df, output_dir='.'):
    """Create politeness strategy analysis"""

    # Filter for relevant data
    df_filtered = df[df['PromptTone'].isin(['Polite', 'Threatening'])].copy()

    # Parse politeness strategies
    df_filtered['Parsed_Strategies'] = df_filtered['Response_ValidatedStrategies'].apply(parse_strategies)

    # Explode strategies to separate rows
    strategy_data = df_filtered.explode('Parsed_Strategies')
    strategy_data = strategy_data[strategy_data['Parsed_Strategies'].notna()]

    # Set up plotting
    setup_plot_style()
    sns.set_style("whitegrid")

    # Create figure with subplots
    fig, axes = plt.subplots(1, 2, figsize=(20, 8))
    fig.suptitle('Politeness Strategy Analysis by Prompt Tone', fontsize=18, y=0.98)

    # Plot 1: Strategy frequency by prompt tone
    strategy_counts = strategy_data.groupby(['Parsed_Strategies', 'PromptTone']).size().unstack(fill_value=0)

    # Get top strategies
    total_counts = strategy_counts.sum(axis=1).sort_values(ascending=False)
    top_strategies = total_counts.head(15).index

    strategy_counts_top = strategy_counts.loc[top_strategies]

    # Create bar plot
    strategy_counts_top.plot(kind='bar', ax=axes[0], width=0.8)
    axes[0].set_title('Top 15 Politeness Strategies by Prompt Tone')
    axes[0].set_xlabel('Politeness Strategies')
    axes[0].set_ylabel('Frequency')
    axes[0].tick_params(axis='x', rotation=45)
    axes[0].legend(title='Prompt Tone')

    # Plot 2: Politeness score distribution by prompt tone
    sns.boxplot(ax=axes[1], x='PromptTone', y='Response_ValidatedPolitenessScore',
                data=df_filtered, palette='muted')
    axes[1].set_title('Politeness Score Distribution by Prompt Tone')
    axes[1].set_xlabel('Prompt Tone')
    axes[1].set_ylabel('Politeness Score')

    plt.tight_layout(rect=[0, 0.03, 1, 0.95])

    # Save the figure
    output_path = os.path.join(output_dir, 'politeness_strategy_analysis.png')
    save_figure(fig, output_path)
    plt.close(fig)

    return strategy_data, strategy_counts

def print_strategy_statistics(strategy_data, strategy_counts):
    """Print politeness strategy statistics"""
    print("\n" + "="*60)
    print("POLITENESS STRATEGY STATISTICS")
    print("="*60)

    # Overall strategy counts
    print("\nTop 10 Most Common Strategies:")
    total_strategy_counts = strategy_counts.sum(axis=1).sort_values(ascending=False)
    for i, (strategy, count) in enumerate(total_strategy_counts.head(10).items(), 1):
        print(f"{i:2d}. {strategy}: {count} occurrences")

    # Strategy differences between tones
    print(f"\nStrategy Usage Differences (Threatening - Polite):")
    if 'Threatening' in strategy_counts.columns and 'Polite' in strategy_counts.columns:
        differences = strategy_counts['Threatening'] - strategy_counts['Polite']
        differences_sorted = differences.sort_values(ascending=False)

        print("Strategies more common in threatening responses:")
        for strategy, diff in differences_sorted.head(5).items():
            if diff > 0:
                print(f"  {strategy}: +{diff}")

        print("\nStrategies more common in polite responses:")
        for strategy, diff in differences_sorted.tail(5).items():
            if diff < 0:
                print(f"  {strategy}: {diff}")

    # Unique strategies per tone
    polite_strategies = set(strategy_data[strategy_data['PromptTone'] == 'Polite']['Parsed_Strategies'].dropna())
    threat_strategies = set(strategy_data[strategy_data['PromptTone'] == 'Threatening']['Parsed_Strategies'].dropna())

    print(f"\nUnique strategies in polite responses only: {len(polite_strategies - threat_strategies)}")
    print(f"Unique strategies in threatening responses only: {len(threat_strategies - polite_strategies)}")
    print(f"Shared strategies: {len(polite_strategies & threat_strategies)}")

def main():
    """Main execution function"""
    script_dir = os.path.dirname(__file__)
    dataset_path = os.path.join(script_dir, '..', '..', 'final_dataset.csv')

    df = load_dataset(dataset_path)
    if df is None:
        return

    print("Starting Politeness Strategy Analysis...")

    output_dir = os.path.dirname(__file__)

    # Generate analysis
    strategy_data, strategy_counts = create_politeness_strategy_analysis(df, output_dir)

    # Print statistics
    print_strategy_statistics(strategy_data, strategy_counts)

    print("\nPoliteness Strategy Analysis completed!")

if __name__ == "__main__":
    main()