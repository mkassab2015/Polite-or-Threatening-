#!/usr/bin/env python3
"""
Paired Comparison Analysis
==========================

This script creates scatter plots showing direct paired comparisons between
polite and threatening responses for the same tasks, emphasizing the paired
nature of the experimental design.
"""

import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'shared'))

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from data_loader import load_dataset
from plotting_utils import setup_plot_style, save_figure

def create_paired_analysis(df, output_dir='.'):
    """Create paired comparison scatter plots"""

    # Filter for only 'Polite' and 'Threatening' tones
    df_filtered = df[df['PromptTone'].isin(['Polite', 'Threatening'])].copy()

    # Reshape data for paired analysis
    metrics = ['Response_SentimentScore', 'RoBERTa_Response_ToxicityScore',
               'Response_ValidatedPolitenessScore', 'ResponseLength']

    pivot_data = df_filtered.pivot_table(
        index=['TaskID', 'Model'],
        columns='PromptTone',
        values=metrics,
        aggfunc='first'
    ).reset_index()

    # Flatten column names
    pivot_data.columns = ['_'.join(col).strip() if col[1] else col[0] for col in pivot_data.columns.values]

    # Set up the plot style
    setup_plot_style()
    sns.set_style("whitegrid")

    # Create 2x2 subplot figure
    fig, axes = plt.subplots(2, 2, figsize=(16, 12))
    fig.suptitle('Paired Comparison: Polite vs. Threatening Responses', fontsize=20, y=0.98)

    # Plot 1: Sentiment Score
    polite_col = 'Response_SentimentScore_Polite'
    threat_col = 'Response_SentimentScore_Threatening'
    if polite_col in pivot_data.columns and threat_col in pivot_data.columns:
        sns.scatterplot(ax=axes[0,0], x=polite_col, y=threat_col,
                       data=pivot_data, alpha=0.6, s=50)
        axes[0,0].plot([pivot_data[polite_col].min(), pivot_data[polite_col].max()],
                      [pivot_data[polite_col].min(), pivot_data[polite_col].max()],
                      'r--', alpha=0.75, label='Equal Response')
        axes[0,0].set_xlabel('Polite Prompt Sentiment')
        axes[0,0].set_ylabel('Threatening Prompt Sentiment')
        axes[0,0].set_title('Sentiment Score Comparison')
        axes[0,0].legend()

    # Plot 2: Toxicity Score
    polite_col = 'RoBERTa_Response_ToxicityScore_Polite'
    threat_col = 'RoBERTa_Response_ToxicityScore_Threatening'
    if polite_col in pivot_data.columns and threat_col in pivot_data.columns:
        sns.scatterplot(ax=axes[0,1], x=polite_col, y=threat_col,
                       data=pivot_data, alpha=0.6, s=50, color='orange')
        axes[0,1].plot([pivot_data[polite_col].min(), pivot_data[polite_col].max()],
                      [pivot_data[polite_col].min(), pivot_data[polite_col].max()],
                      'r--', alpha=0.75, label='Equal Response')
        axes[0,1].set_xlabel('Polite Prompt Toxicity')
        axes[0,1].set_ylabel('Threatening Prompt Toxicity')
        axes[0,1].set_title('Toxicity Score Comparison')
        axes[0,1].legend()

    # Plot 3: Politeness Score
    polite_col = 'Response_ValidatedPolitenessScore_Polite'
    threat_col = 'Response_ValidatedPolitenessScore_Threatening'
    if polite_col in pivot_data.columns and threat_col in pivot_data.columns:
        sns.scatterplot(ax=axes[1,0], x=polite_col, y=threat_col,
                       data=pivot_data, alpha=0.6, s=50, color='green')
        axes[1,0].plot([pivot_data[polite_col].min(), pivot_data[polite_col].max()],
                      [pivot_data[polite_col].min(), pivot_data[polite_col].max()],
                      'r--', alpha=0.75, label='Equal Response')
        axes[1,0].set_xlabel('Polite Prompt Politeness')
        axes[1,0].set_ylabel('Threatening Prompt Politeness')
        axes[1,0].set_title('Politeness Score Comparison')
        axes[1,0].legend()

    # Plot 4: Response Length
    polite_col = 'ResponseLength_Polite'
    threat_col = 'ResponseLength_Threatening'
    if polite_col in pivot_data.columns and threat_col in pivot_data.columns:
        sns.scatterplot(ax=axes[1,1], x=polite_col, y=threat_col,
                       data=pivot_data, alpha=0.6, s=50, color='purple')
        axes[1,1].plot([pivot_data[polite_col].min(), pivot_data[polite_col].max()],
                      [pivot_data[polite_col].min(), pivot_data[polite_col].max()],
                      'r--', alpha=0.75, label='Equal Response')
        axes[1,1].set_xlabel('Polite Prompt Length')
        axes[1,1].set_ylabel('Threatening Prompt Length')
        axes[1,1].set_title('Response Length Comparison')
        axes[1,1].legend()

    plt.tight_layout(rect=[0, 0.03, 1, 0.95])

    # Save the figure
    output_path = os.path.join(output_dir, 'paired_comparison_analysis.png')
    save_figure(fig, output_path)
    plt.close(fig)

    return pivot_data

def print_paired_statistics(pivot_data):
    """Print paired comparison statistics"""
    print("\n" + "="*50)
    print("PAIRED COMPARISON STATISTICS")
    print("="*50)

    metrics_pairs = [
        ('Response_SentimentScore_Polite', 'Response_SentimentScore_Threatening', 'Sentiment'),
        ('RoBERTa_Response_ToxicityScore_Polite', 'RoBERTa_Response_ToxicityScore_Threatening', 'Toxicity'),
        ('Response_ValidatedPolitenessScore_Polite', 'Response_ValidatedPolitenessScore_Threatening', 'Politeness'),
        ('ResponseLength_Polite', 'ResponseLength_Threatening', 'Length')
    ]

    for polite_col, threat_col, metric_name in metrics_pairs:
        if polite_col in pivot_data.columns and threat_col in pivot_data.columns:
            diff = pivot_data[threat_col] - pivot_data[polite_col]
            print(f"\n{metric_name} Score Differences (Threatening - Polite):")
            print(f"  Mean difference: {diff.mean():.4f}")
            print(f"  Std difference: {diff.std():.4f}")
            print(f"  Tasks where threatening > polite: {(diff > 0).sum()}/{len(diff)} ({(diff > 0).mean()*100:.1f}%)")

def main():
    """Main execution function"""
    script_dir = os.path.dirname(__file__)
    dataset_path = os.path.join(script_dir, '..', '..', 'final_dataset.csv')

    df = load_dataset(dataset_path)
    if df is None:
        return

    print("Starting Paired Comparison Analysis...")

    output_dir = os.path.dirname(__file__)

    # Generate paired analysis
    pivot_data = create_paired_analysis(df, output_dir)

    # Print statistics
    print_paired_statistics(pivot_data)

    print("\nPaired Comparison Analysis completed!")

if __name__ == "__main__":
    main()