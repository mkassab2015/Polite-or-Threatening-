# Paired Comparison Analysis

## Overview
This analysis emphasizes the paired nature of the experimental design by directly comparing AI responses to the same tasks under polite versus threatening prompts.

## What This Analysis Shows

### 1. Sentiment Score Paired Comparison
- **Purpose**: Direct comparison of sentiment between polite and threatening versions of the same task
- **Visualization**: Scatter plot with polite responses on x-axis, threatening on y-axis
- **Key Insight**: Points below the diagonal line indicate more negative sentiment for threatening prompts

### 2. Toxicity Score Paired Comparison
- **Purpose**: Compare toxicity levels for identical tasks with different prompt tones
- **Visualization**: Scatter plot showing paired toxicity scores
- **Key Insight**: Points above the diagonal suggest threatening prompts elicit more toxic responses

### 3. Politeness Score Paired Comparison
- **Purpose**: Examine how response politeness changes for the same task with different prompt tones
- **Visualization**: Direct paired comparison of politeness scores
- **Key Insight**: Points below diagonal indicate less polite responses to threatening prompts

### 4. Response Length Paired Comparison
- **Purpose**: Compare response verbosity for identical tasks under different prompt tones
- **Visualization**: Scatter plot of response lengths
- **Key Insight**: Reveals whether threatening prompts lead to shorter or longer responses

## Methodology
- **Data Reshaping**: Pivots data to create paired observations for the same TaskID
- **Scatter Plots**: Each point represents one task with polite vs. threatening responses
- **Diagonal Reference Line**: Red dashed line shows where responses would be identical
- **Statistical Summary**: Provides difference statistics and proportions

## Key Features
- **Paired Design Focus**: Directly compares responses to identical tasks
- **Reference Lines**: Diagonal lines help identify which prompt tone produces stronger effects
- **Difference Analysis**: Calculates mean differences and proportion of tasks showing effects
- **Task-Level Insights**: Each point represents a complete task comparison

## Files Generated
- `paired_comparison_analysis.png`: Complete 2x2 paired comparison visualization
- Console output with paired difference statistics

## Interpretation Guide
- **Points on Diagonal**: Indicate no difference between prompt tones
- **Points Below Diagonal**: Threatening prompts produce lower scores (for sentiment/politeness)
- **Points Above Diagonal**: Threatening prompts produce higher scores (for toxicity/length)
- **Scatter Pattern**: Tight clustering suggests consistent effects; wide scatter suggests variable effects
- **Difference Statistics**: Mean differences quantify overall effect sizes

This analysis provides the most direct evidence of prompt tone effects by controlling for task content and focusing purely on how the same AI models respond differently to tone variations.