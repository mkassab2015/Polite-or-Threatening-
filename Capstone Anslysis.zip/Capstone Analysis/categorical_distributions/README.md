# Categorical Distributions Analysis

## Overview
This analysis transforms continuous response metrics into meaningful categorical variables and examines how AI responses fall into different behavioral categories based on prompt tone.

## What This Analysis Shows

### 1. Sentiment Category Distribution (VADER-based)
- **Purpose**: Categorizes sentiment scores into Negative (<-0.05), Neutral (-0.05 to 0.05), and Positive (>0.05)
- **Visualization**: Count plot with annotations showing exact frequencies
- **Key Insight**: Reveals whether threatening prompts lead to more negative response categories

### 2. Toxicity Category Distribution (RoBERTa-based)
- **Purpose**: Classifies toxicity scores into five levels: Very Low, Low, Moderate, High, Very High
- **Thresholds**: Based on RoBERTa model research (0.1, 0.3, 0.5, 0.7 cutoffs)
- **Key Insight**: Shows distribution of harmful content risk across prompt tones

### 3. Politeness Category Distribution
- **Purpose**: Groups politeness scores into interpretable categories from Very Impolite to Very Polite
- **Thresholds**: Based on Stanford/Cornell politeness research (1-2, 2-3, 3-4, 4-5 ranges)
- **Key Insight**: Demonstrates how prompt tone affects response courtesy levels

### 4. Response Length Distribution
- **Purpose**: Shows response verbosity patterns using box plots with mean indicators
- **Visualization**: Box plots with white circle markers indicating mean values
- **Key Insight**: Reveals whether threatening prompts lead to shorter or longer responses

## Methodology
- **Evidence-Based Thresholds**: Uses research-validated cutoff points for categorization
- **Count-Based Analysis**: Shows absolute frequencies with annotations
- **Cross-Tabulation**: Provides detailed breakdowns by prompt tone
- **Descriptive Statistics**: Includes comprehensive statistical summaries

## Categorization Thresholds

### Sentiment (VADER Scale)
- **Negative**: Score < -0.05 (clearly negative sentiment)
- **Neutral**: -0.05 ≤ Score ≤ 0.05 (neutral sentiment)
- **Positive**: Score > 0.05 (clearly positive sentiment)

### Toxicity (RoBERTa Scale)
- **Very Low**: Score < 0.1 (minimal toxicity risk)
- **Low**: 0.1 ≤ Score < 0.3 (low toxicity risk)
- **Moderate**: 0.3 ≤ Score < 0.5 (moderate concern)
- **High**: 0.5 ≤ Score < 0.7 (high toxicity risk)
- **Very High**: Score ≥ 0.7 (severe toxicity)

### Politeness (1-5 Scale)
- **Very Impolite**: Score 1.0-1.9 (hostile/rude)
- **Somewhat Impolite**: Score 2.0-2.9 (mildly impolite)
- **Neutral**: Score 3.0-3.9 (neither polite nor impolite)
- **Somewhat Polite**: Score 4.0-4.9 (mildly polite)
- **Very Polite**: Score 5.0+ (highly courteous)

## Files Generated
- `categorical_distributions_analysis.png`: Complete 2x2 categorical analysis visualization
- Console output with cross-tabulation tables and descriptive statistics

## Interpretation Guide
- **Count Annotations**: Numbers on bars show exact response frequencies
- **Cross-Tabulation Tables**: Show relationship between categories and prompt tones
- **Box Plot Elements**:
  - Center line: Median response length
  - Box: Interquartile range (25th-75th percentile)
  - White circle: Mean response length
  - Whiskers: Data range excluding outliers

## Research Applications
1. **Content Moderation**: Understanding toxicity risk distributions
2. **Behavioral Psychology**: Categorizing response emotional patterns
3. **Human-AI Interaction**: Assessing politeness consistency across conditions
4. **Safety Assessment**: Quantifying proportion of concerning responses

This analysis provides actionable insights by transforming complex continuous metrics into interpretable categorical outcomes that can inform policy and safety decisions.