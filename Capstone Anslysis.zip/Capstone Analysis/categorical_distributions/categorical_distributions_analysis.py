#!/usr/bin/env python3
"""
Categorical Distributions Analysis
==================================

This script categorizes sentiment, toxicity, and politeness scores into
meaningful categories and analyzes their distribution across prompt tones.
"""

import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'shared'))

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
from data_loader import load_dataset
from plotting_utils import setup_plot_style, save_figure

warnings.filterwarnings('ignore')

def create_categorical_analysis(df, output_dir='.'):
    """Create categorical distributions analysis"""

    # Filter and process data
    df_processed = df[df['PromptTone'].isin(['Polite', 'Threatening'])].copy()

    # 1. Categorize Sentiment Score based on VADER thresholds
    sentiment_bins = [-float('inf'), -0.05, 0.05, float('inf')]
    sentiment_labels = ['Negative', 'Neutral', 'Positive']
    df_processed['SentimentCategory'] = pd.cut(
        df_processed['Response_SentimentScore'],
        bins=sentiment_bins,
        labels=sentiment_labels,
        right=False
    )

    # 2. Categorize Toxicity Score based on RoBERTa thresholds
    toxicity_bins = [-float('inf'), 0.1, 0.3, 0.5, 0.7, float('inf')]
    toxicity_labels = ['Very Low', 'Low', 'Moderate', 'High', 'Very High']
    df_processed['ToxicityCategory'] = pd.cut(
        df_processed['RoBERTa_Response_ToxicityScore'],
        bins=toxicity_bins,
        labels=toxicity_labels,
        right=False
    )
    df_processed['ToxicityCategory'] = pd.Categorical(
        df_processed['ToxicityCategory'],
        categories=toxicity_labels,
        ordered=True
    )

    # 3. Categorize Politeness Score based on research thresholds
    politeness_bins = [0, 1.9, 2.9, 3.9, 4.9, 5.1]
    politeness_labels = ['Very Impolite', 'Somewhat Impolite', 'Neutral', 'Somewhat Polite', 'Very Polite']
    df_processed['PolitenessCategory'] = pd.cut(
        df_processed['Response_ValidatedPolitenessScore'],
        bins=politeness_bins,
        labels=politeness_labels,
        right=False
    )
    df_processed['PolitenessCategory'] = pd.Categorical(
        df_processed['PolitenessCategory'],
        categories=politeness_labels,
        ordered=True
    )

    # Set up plotting
    setup_plot_style()
    sns.set_theme(style="whitegrid", context="talk")
    fig, axes = plt.subplots(2, 2, figsize=(22, 18))
    fig.suptitle('Categorical Analysis of Model Responses to Polite vs. Threatening Prompts',
                 fontsize=28, y=1.02)

    # Plot 1: Sentiment Score Distribution
    ax1 = sns.countplot(ax=axes[0, 0], data=df_processed, x='SentimentCategory',
                       hue='PromptTone', palette='viridis', order=sentiment_labels)
    axes[0, 0].set_title('1) Distribution of Response Sentiment Categories', fontsize=20)
    axes[0, 0].set_xlabel('Sentiment Category (VADER)', fontsize=16)
    axes[0, 0].set_ylabel('Count of Responses', fontsize=16)
    axes[0, 0].legend(title='Prompt Tone')
    # Add annotations
    for p in ax1.patches:
        ax1.annotate(f'{int(p.get_height())}',
                    (p.get_x() + p.get_width() / 2., p.get_height()),
                    ha='center', va='center', xytext=(0, 9), textcoords='offset points', fontsize=14)

    # Plot 2: Toxicity Score Distribution
    ax2 = sns.countplot(ax=axes[0, 1], data=df_processed, x='ToxicityCategory',
                       hue='PromptTone', palette='rocket')
    axes[0, 1].set_title('2) Distribution of Response Toxicity Categories', fontsize=20)
    axes[0, 1].set_xlabel('Toxicity Category (RoBERTa)', fontsize=16)
    axes[0, 1].set_ylabel('Count of Responses', fontsize=16)
    axes[0, 1].legend(title='Prompt Tone')
    # Add annotations
    for p in ax2.patches:
        ax2.annotate(f'{int(p.get_height())}',
                    (p.get_x() + p.get_width() / 2., p.get_height()),
                    ha='center', va='center', xytext=(0, 9), textcoords='offset points', fontsize=14)

    # Plot 3: Politeness Score Distribution
    ax3 = sns.countplot(ax=axes[1, 0], data=df_processed, x='PolitenessCategory',
                       hue='PromptTone', palette='mako')
    axes[1, 0].set_title('3) Distribution of Response Politeness Categories', fontsize=20)
    axes[1, 0].set_xlabel('Politeness Category', fontsize=16)
    axes[1, 0].set_ylabel('Count of Responses', fontsize=16)
    axes[1, 0].tick_params(axis='x', rotation=45)
    axes[1, 0].legend(title='Prompt Tone')
    # Add annotations
    for p in ax3.patches:
        ax3.annotate(f'{int(p.get_height())}',
                    (p.get_x() + p.get_width() / 2., p.get_height()),
                    ha='center', va='center', xytext=(0, 9), textcoords='offset points', fontsize=14)

    # Plot 4: Response Length Distribution
    sns.boxplot(ax=axes[1, 1], data=df_processed, x='PromptTone', y='ResponseLength',
               palette='flare', showmeans=True,
               meanprops={"marker":"o", "markerfacecolor":"white", "markeredgecolor":"black", "markersize":"10"})
    axes[1, 1].set_title('4) Distribution of Response Length', fontsize=20)
    axes[1, 1].set_xlabel('Prompt Tone', fontsize=16)
    axes[1, 1].set_ylabel('Length (Number of Characters)', fontsize=16)
    # Add a note about the marker
    axes[1, 1].text(0.95, 0.95, 'White circle is mean length',
                   transform=axes[1, 1].transAxes, fontsize=12,
                   verticalalignment='top', horizontalalignment='right',
                   bbox=dict(boxstyle='round,pad=0.5', fc='wheat', alpha=0.5))

    plt.tight_layout(rect=[0, 0.03, 1, 0.96])

    # Save the figure
    output_path = os.path.join(output_dir, 'categorical_distributions_analysis.png')
    save_figure(fig, output_path)
    plt.close(fig)

    return df_processed

def print_categorical_statistics(df_processed):
    """Print detailed categorical statistics"""
    print("\n" + "="*60)
    print("CATEGORICAL DISTRIBUTIONS ANALYSIS")
    print("="*60)

    # Sentiment categories
    print("\nSentiment Categories Distribution:")
    sentiment_crosstab = pd.crosstab(df_processed['SentimentCategory'],
                                   df_processed['PromptTone'], margins=True)
    print(sentiment_crosstab)

    # Toxicity categories
    print("\nToxicity Categories Distribution:")
    toxicity_crosstab = pd.crosstab(df_processed['ToxicityCategory'],
                                  df_processed['PromptTone'], margins=True)
    print(toxicity_crosstab)

    # Politeness categories
    print("\nPoliteness Categories Distribution:")
    politeness_crosstab = pd.crosstab(df_processed['PolitenessCategory'],
                                    df_processed['PromptTone'], margins=True)
    print(politeness_crosstab)

    # Response length statistics
    print("\nResponse Length Statistics by Category:")
    length_stats = df_processed.groupby('PromptTone')['ResponseLength'].describe()
    print(length_stats)

def main():
    """Main execution function"""
    script_dir = os.path.dirname(__file__)
    dataset_path = os.path.join(script_dir, '..', '..', 'final_dataset.csv')

    df = load_dataset(dataset_path)
    if df is None:
        return

    print("Starting Categorical Distributions Analysis...")

    output_dir = os.path.dirname(__file__)

    # Generate analysis
    df_processed = create_categorical_analysis(df, output_dir)

    # Print statistics
    print_categorical_statistics(df_processed)

    print("\nCategorical Distributions Analysis completed!")

if __name__ == "__main__":
    main()