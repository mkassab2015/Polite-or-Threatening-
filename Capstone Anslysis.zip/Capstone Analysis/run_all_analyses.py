#!/usr/bin/env python3
"""
Master Analysis Runner
======================

This script runs all available capstone analyses and generates
a comprehensive report with all visualizations and statistics.
"""

import os
import sys
import subprocess
import time
from pathlib import Path

def run_analysis(analysis_dir, script_name, description):
    """Run a single analysis script and report results"""
    print(f"\n{'='*60}")
    print(f"RUNNING: {description}")
    print(f"{'='*60}")

    script_path = os.path.join(analysis_dir, script_name)

    if not os.path.exists(script_path):
        print(f"❌ Script not found: {script_path}")
        return False

    try:
        start_time = time.time()
        result = subprocess.run(
            [sys.executable, script_path],
            cwd=analysis_dir,
            capture_output=True,
            text=True,
            timeout=120  # 2 minute timeout per analysis
        )

        end_time = time.time()
        duration = end_time - start_time

        if result.returncode == 0:
            print(f"✅ SUCCESS ({duration:.1f}s)")
            print("Output:")
            print(result.stdout)
            return True
        else:
            print(f"❌ FAILED ({duration:.1f}s)")
            print("Error:")
            print(result.stderr)
            return False

    except subprocess.TimeoutExpired:
        print(f"⏰ TIMEOUT (>120s)")
        return False
    except Exception as e:
        print(f"❌ ERROR: {e}")
        return False

def main():
    """Run all analyses"""
    script_dir = os.path.dirname(os.path.abspath(__file__))

    # Define analyses to run (in order of complexity/dependency)
    analyses = [
        ("01_basic_stripplots", "basic_stripplot_analysis.py", "Basic Stripplot Analysis"),
        ("02_faceted_by_model", "faceted_model_analysis.py", "Faceted Model Analysis"),
        ("03_categorical_distributions", "categorical_distributions_analysis.py", "Categorical Distributions Analysis"),
        ("04_paired_comparison", "paired_comparison_analysis.py", "Paired Comparison Analysis"),
        ("05_politeness_strategies", "politeness_strategy_analysis.py", "Politeness Strategy Analysis"),
        ("07_raincloud_distributions", "raincloud_analysis.py", "Raincloud Distributions Analysis"),
        ("08_cross_context_analysis", "cross_context_analysis.py", "Cross-Context Analysis"),
        ("09_safety_behaviors", "safety_behavior_analysis.py", "Safety Behavior Analysis"),
        ("12_model_comprehensive", "model_comprehensive_analysis.py", "Model Comprehensive Analysis"),
        ("13_task_comprehensive", "task_comprehensive_analysis.py", "Task Comprehensive Analysis"),
        ("14_response_length", "response_length_analysis.py", "Response Length Analysis"),
    ]

    print("🚀 CAPSTONE ANALYSIS SUITE")
    print(f"📁 Working directory: {script_dir}")
    print(f"📊 Total analyses to run: {len(analyses)}")

    # Check if dataset exists
    dataset_path = os.path.join(script_dir, '..', 'final_dataset.csv')
    if not os.path.exists(dataset_path):
        print(f"❌ Dataset not found: {dataset_path}")
        print("Please ensure 'final_dataset.csv' is in the parent directory")
        return

    print(f"✅ Dataset found: {dataset_path}")

    # Run each analysis
    results = []
    successful = 0
    failed = 0

    for analysis_dir, script_name, description in analyses:
        full_analysis_path = os.path.join(script_dir, analysis_dir)

        if not os.path.exists(full_analysis_path):
            print(f"⚠️  Directory not found: {full_analysis_path}")
            results.append((description, False, "Directory not found"))
            failed += 1
            continue

        success = run_analysis(full_analysis_path, script_name, description)
        results.append((description, success, "Success" if success else "Failed"))

        if success:
            successful += 1
        else:
            failed += 1

    # Final summary
    print(f"\n{'='*60}")
    print("FINAL SUMMARY")
    print(f"{'='*60}")

    print(f"✅ Successful analyses: {successful}")
    print(f"❌ Failed analyses: {failed}")
    print(f"📊 Total analyses: {len(analyses)}")

    print(f"\nDetailed Results:")
    for description, success, status in results:
        status_icon = "✅" if success else "❌"
        print(f"  {status_icon} {description}: {status}")

    # List generated files
    print(f"\nGenerated Files:")
    for analysis_dir, _, _ in analyses:
        full_analysis_path = os.path.join(script_dir, analysis_dir)
        if os.path.exists(full_analysis_path):
            png_files = list(Path(full_analysis_path).glob('*.png'))
            if png_files:
                print(f"  📁 {analysis_dir}:")
                for png_file in png_files:
                    print(f"    🖼️  {png_file.name}")

    if successful == len(analyses):
        print(f"\n🎉 All analyses completed successfully!")
    else:
        print(f"\n⚠️  {failed} analyses failed. Check error messages above.")

    print(f"\n📖 Check individual README.md files in each directory for analysis explanations.")

if __name__ == "__main__":
    main()